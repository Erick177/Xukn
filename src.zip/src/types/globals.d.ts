@import "tailwindcss";

:root {
  --bg-main: #0c0d14;
  --bg-panel: #161a25;
  --bg-input: #1e222d;
  --bg-btn: #2a2e39;
  --border-color: #363c4e;
  --text-main: #d1d4dc;
  --text-muted: #787b86;
  --accent-blue: #2962ff;
  --accent-green: #26a69a;
  --accent-red: #ef5350;
  --accent-orange: #ff9800;
}

*, *::before, *::after { box-sizing: border-box; }

html, body { height: 100%; }

body {
  margin: 0;
  padding: 0;
  background: var(--bg-main);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  overflow: hidden;
  color: var(--text-main);
  user-select: none;
  direction: ltr;
  font-size: 12px;
}

#tv_chart_container {
  width: 100%;
  height: 100vh;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
}

#sidebar-panel {
  position: absolute;
  top: 5px;
  right: 11%;
  width: auto;
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  z-index: 5;
  box-shadow: none;
  display: flex;
  flex-direction: column !important;
  align-items: flex-end;
  gap: 5px;
  pointer-events: none;
}
#sidebar-panel > * { pointer-events: auto; }

.sidebar-top-row {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 15px;
}

.btn {
  background: var(--bg-btn);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  border-radius: 4px;
  padding: 4px 10px;
  font-size: 11px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  height: 28px;
  box-sizing: border-box;
  font-weight: 500;
  transition: background .12s, box-shadow .12s;
}
.btn:hover { background: var(--border-color); }
.btn svg { width: 12px; height: 12px; flex-shrink: 0; }
.btn-blue { background: var(--accent-blue); border-color: var(--accent-blue); color: #fff; }
.btn-blue:hover { background: #4d7aff; box-shadow: 0 0 10px rgba(41,98,255,.4); }
.btn-green { background: var(--accent-green); border-color: var(--accent-green); color: #021a17; }
.btn-green:hover { background: #2ec4ae; box-shadow: 0 0 10px rgba(38,166,154,.4); }
.btn-red { background: var(--accent-red); border-color: var(--accent-red); color: #fff; }
.btn-red:hover { background: #f36669; box-shadow: 0 0 10px rgba(239,83,80,.4); }
.btn-orange { background: var(--accent-orange); border-color: var(--accent-orange); color: #1a0000; }
.btn-orange:hover { background: #ffad33; }
.btn-icon { width: 28px; height: 28px; padding: 0; }
.btn:disabled { opacity: .55; cursor: not-allowed; }

.btn-icon-row {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  gap: 5px;
}
.btn-icon-row .btn {
  width: 29px;
  height: 29px;
  padding: 0;
  flex-shrink: 0;
  border-radius: 5px;
}
.btn-icon-row .btn svg { width: 14px; height: 14px; }

.control-input {
  background: var(--bg-input);
  border: 1px solid var(--border-color);
  color: #fff;
  border-radius: 4px;
  padding: 4px 6px;
  font-size: 11px;
  box-sizing: border-box;
  outline: none;
  font-family: inherit;
  transition: border-color .15s;
}
.control-input:focus { border-color: var(--accent-blue); }

.panel-row { display: flex; align-items: center; gap: 6px; font-size: 12px; white-space: nowrap; }

#balance-row { background: transparent; border: none; border-radius: 0; padding: 0; }
#current-balance { font-weight: 700; font-size: 14px; color: var(--accent-green); font-variant-numeric: tabular-nums; }

#trade-panel-container {
  display: none;
  background: var(--bg-panel);
  border: 1px solid var(--border-color);
  border-radius: 6px;
  padding: 8px;
  flex-direction: column;
  gap: 6px;
  position: relative !important;
  top: auto !important;
  right: auto !important;
  width: 200px;
  box-shadow: 0 8px 28px rgba(0,0,0,.55);
}
#trade-panel-container.open { display: flex; }
#limit-price-row { display: none; }

#active-positions-list {
  max-height: 200px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 4px;
  position: relative !important;
  top: auto !important;
  right: auto !important;
  width: 45% !important;
  margin-top: 5px;
  margin-left: auto;
}
.position-card { border-radius: 4px; padding: 5px 8px; font-size: 11px; background: var(--bg-input); transition: background .12s; }
.position-card:hover { background: var(--bg-btn); }
.pos-buy { border-left: 3px solid var(--accent-green); }
.pos-sell { border-left: 3px solid var(--accent-red); }

#pending-orders-container {
  display: none;
  text-align: center;
  font-size: 10px;
  color: var(--text-muted);
  background: var(--bg-input);
  border: 1px solid var(--border-color);
  border-radius: 4px;
  padding: 2px 6px;
  position: relative !important;
  top: auto !important;
  right: auto !important;
  width: 45% !important;
  margin-top: 5px;
  margin-left: auto;
}

#floating-control-bar {
  position: absolute;
  bottom: 28px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--bg-panel);
  border: 1px solid var(--border-color);
  border-radius: 24px;
  padding: 5px 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  box-shadow: 0 8px 28px rgba(0,0,0,.6);
  z-index: 10;
}
#floating-control-bar.collapsed > *:not(#btn-collapse) { display: none !important; }
#btn-collapse { border-radius: 50%; width: 22px; height: 22px; padding: 0; font-size: 14px; line-height: 1; }
#replay-speed-slider { width: 80px; accent-color: var(--accent-blue); cursor: pointer; }

.modal-overlay { position: fixed; inset: 0; background: rgba(8,9,14,.88); backdrop-filter: blur(4px); z-index: 100; display: none; align-items: center; justify-content: center; }
.modal-overlay.active { display: flex; }
.modal-content { background: var(--bg-panel); border: 1px solid var(--border-color); border-radius: 12px; padding: 24px; box-shadow: 0 16px 48px rgba(0,0,0,.7); color: var(--text-main); display: flex; flex-direction: column; }
.modal-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 4px; }

#dashboard-overlay .modal-content { width: 100vw; height: 100vh; border-radius: 0 !important; border: none; padding: 30px; }
.session-grid { display: grid; grid-template-columns: 320px 1fr; gap: 24px; margin-top: 16px; flex: 1; min-height: 0; transition: grid-template-columns 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
.session-grid.hide-form { grid-template-columns: 0px 1fr; }
.form-section { border-right: 1px solid var(--border-color); padding-right: 20px; display: flex; flex-direction: column; gap: 8px; overflow-y: auto; transition: transform 0.3s, opacity 0.3s, padding 0.3s; }
.session-grid.hide-form .form-section { transform: translateX(-100%); opacity: 0; padding: 0; border: none; pointer-events: none; }

.list-section { flex: 1; overflow-y: auto; display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); grid-auto-rows: minmax(220px, max-content); gap: 16px; align-content: start; padding-bottom: 20px; }
.field-label { font-size: 10px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .05em; }

.sess-card { border: 1px solid var(--border-color); border-radius: 12px; background: var(--bg-input); padding: 18px; display: flex; flex-direction: column; justify-content: space-between; aspect-ratio: 1 / 1; box-sizing: border-box; }
.sess-card.sess-active { border-color: var(--accent-blue); }

#history-modal .modal-content { width: 360px; max-height: 460px; }
#history-list { flex: 1; overflow-y: auto; font-size: 11px; font-family: monospace; background: var(--bg-input); border: 1px solid var(--border-color); border-radius: 4px; padding: 8px; line-height: 1.8; }

#kb-hints { position: absolute; bottom: 8px; left: 14px; z-index: 10; display: flex; gap: 10px; align-items: center; color: var(--text-muted); font-size: 10px; opacity: .45; transition: opacity .2s; }
#kb-hints:hover { opacity: 1; }
.kbd { background: var(--bg-input); border: 1px solid var(--border-color); border-radius: 3px; padding: 1px 5px; font-size: 9px; font-family: monospace; }

#pos-detail-panel {
  display: none;
  position: fixed;
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--bg-panel);
  border: 1px solid var(--border-color);
  border-radius: 12px;
  padding: 14px 16px;
  z-index: 20;
  width: 320px;
  box-shadow: 0 8px 32px rgba(0,0,0,.75);
  flex-direction: column;
  gap: 9px;
}
#pos-detail-panel.active { display: flex; }
.pd-divider { height: 1px; background: var(--border-color); margin: 1px 0; }
.pd-label { font-size: 9px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .05em; }

body.light-theme {
  --bg-main: #f0f2f5;
  --bg-panel: #ffffff;
  --bg-input: #f4f5f7;
  --bg-btn: #e4e6eb;
  --border-color: #d2d6dc;
  --text-main: #1c1e21;
  --text-muted: #606770;
}
body.light-theme .modal-content,
body.light-theme .modal-header,
body.light-theme .sess-card,
body.light-theme .position-card {
  background: #fff !important;
  color: #1c1e21 !important;
}
body.light-theme .control-input { background: #f4f5f7 !important; color: #1c1e21 !important; border-color: #d2d6dc !important; }
body.light-theme #balance-row { background: #f4f5f7 !important; }
body.light-theme .position-card { background: #f4f5f7 !important; }
body.light-theme .position-card:hover { background: #e4e6eb !important; }
body.light-theme #floating-control-bar { background: rgba(255,255,255,0) !important; }