import type { Bar } from "@/lib/types";

/**
 * Parses a raw timestamp string. Accepts ISO strings ("2010-07-08T10:00:00")
 * as well as the space-separated variant commonly found in exported
 * broker/tick data ("2010-07-08 10:00:00").
 */
function parseTime(raw: string): number {
  const trimmed = raw.trim();
  const normalized = /^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$/.test(trimmed)
    ? trimmed.replace(" ", "T")
    : trimmed;
  return new Date(normalized).getTime();
}

/**
 * Parses a single raw CSV line of the legacy shape:
 *   ISO_DATE,open,high,low,close[,volume]
 * Returns null when the line cannot be parsed.
 */
export function parseCsvLine(line: string): Bar | null {
  if (typeof line !== "string" || !line.trim()) return null;
  const parts = line.split(",");
  if (parts.length < 5) return null;

  const time = parseTime(parts[0]);
  if (Number.isNaN(time)) return null;

  const open = parseFloat(parts[1]);
  const high = parseFloat(parts[2]);
  const low = parseFloat(parts[3]);
  const close = parseFloat(parts[4]);
  const volume = parts[5] ? parseFloat(parts[5]) : 0;

  if ([open, high, low, close].some((n) => Number.isNaN(n))) return null;

  return { time, open, high, low, close, volume };
}

/**
 * Parses a tab-separated line of the shape:
 *   Time  Open  High  Low  Close  Volume  [ExtraVolumeLikeColumn]
 * `volumeColumnIndex` picks which trailing numeric column (5-based index
 * into `parts`) should be treated as the real volume, since some exports
 * carry two volume-like trailing columns (e.g. tick volume + a near-constant
 * digit count column).
 */
export function parseTabLine(line: string, volumeColumnIndex: number): Bar | null {
  if (typeof line !== "string" || !line.trim()) return null;
  const parts = line.split("\t").map((p) => p.trim());
  if (parts.length < 5) return null;

  const time = parseTime(parts[0]);
  if (Number.isNaN(time)) return null;

  const open = parseFloat(parts[1]);
  const high = parseFloat(parts[2]);
  const low = parseFloat(parts[3]);
  const close = parseFloat(parts[4]);
  if ([open, high, low, close].some((n) => Number.isNaN(n))) return null;

  const rawVolume = parts.length > volumeColumnIndex ? parseFloat(parts[volumeColumnIndex]) : NaN;
  const volume = Number.isNaN(rawVolume) ? 0 : rawVolume;

  return { time, open, high, low, close, volume };
}

/** Simple population variance helper used to pick the "real" volume column. */
function variance(values: number[]): number {
  if (values.length === 0) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length;
}

/**
 * Given the trailing columns of a tab-separated file (everything after
 * Close), determine which column index (5-based, into the raw `parts`
 * array) is the true Volume. When there's more than one candidate column
 * (e.g. "Volume" plus an extra unlabeled numeric column), the one with the
 * higher relative variation (coefficient of variation) across a sample of
 * rows wins, since real trading volume fluctuates a lot while incidental
 * counter-like columns tend to stay flat.
 */
export function pickVolumeColumn(dataLines: string[]): number {
  const SAMPLE_SIZE = 300;
  let maxTrailingCols = 0;
  const samples: number[][] = [];

  for (const line of dataLines) {
    if (samples.length >= SAMPLE_SIZE) break;
    const parts = line.split("\t");
    if (parts.length < 6) continue;
    const trailing = parts.slice(5).map((p) => parseFloat(p));
    if (trailing.some((n) => Number.isNaN(n))) continue;
    maxTrailingCols = Math.max(maxTrailingCols, trailing.length);
    samples.push(trailing);
  }

  if (maxTrailingCols <= 1) return 5; // only one candidate column (Volume)

  let bestCol = 0;
  let bestScore = -1;
  for (let col = 0; col < maxTrailingCols; col++) {
    const values = samples.map((s) => s[col]).filter((n) => n !== undefined && !Number.isNaN(n));
    if (values.length === 0) continue;
    const mean = values.reduce((a, b) => a + b, 0) / values.length || 1;
    const cv = Math.sqrt(variance(values)) / Math.abs(mean); // coefficient of variation
    if (cv > bestScore) {
      bestScore = cv;
      bestCol = col;
    }
  }
  return 5 + bestCol;
}

/**
 * Parses the full content of a data file. Auto-detects between:
 *  - legacy comma-separated (no header): ISO_DATE,open,high,low,close[,volume]
 *  - tab-separated with a header row: Time  Open  High  Low  Close  Volume[  Extra]
 */
export function parseCsv(content: string): Bar[] {
  const rawLines = content.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (rawLines.length === 0) return [];

  const isTabDelimited = rawLines[0].includes("\t");

  if (!isTabDelimited) {
    return rawLines
      .map((line) => parseCsvLine(line))
      .filter((bar): bar is Bar => bar !== null)
      .sort((a, b) => a.time - b.time);
  }

  // Tab-delimited: first line may be a header ("Time  Open  High  Low  Close  Volume...").
  const firstLineFirstCell = rawLines[0].split("\t")[0].trim();
  const hasHeader = Number.isNaN(parseTime(firstLineFirstCell));
  const dataLines = hasHeader ? rawLines.slice(1) : rawLines;

  const volumeColumnIndex = pickVolumeColumn(dataLines);

  return dataLines
    .map((line) => parseTabLine(line, volumeColumnIndex))
    .filter((bar): bar is Bar => bar !== null)
    .sort((a, b) => a.time - b.time);
}
