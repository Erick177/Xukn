// src/lib/sessionIO.ts
import type { Session } from "@/lib/types";

const STORAGE_KEY = "replay-sessions-cache";

export function loadSessionsFromBrowser(): Session[] {
  if (typeof window === "undefined") return [];
  
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveSessionsToBrowser(sessions: Session[]): void {
  if (typeof window === "undefined") return;
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  } catch {
    // ignore
  }
}

export function exportSessionsToFile(sessions: Session[]): void {
  const payload = {
    exportedAt: new Date().toISOString(),
    sessions,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `replay-sessions-${new Date().toISOString().slice(0, 10)}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function importSessionsFromFile(file: File): Promise<Session[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = String(reader.result || "");
        const parsed = JSON.parse(text);
        const sessions = Array.isArray(parsed) ? parsed : parsed?.sessions;
        if (!Array.isArray(sessions)) {
          reject(new Error("Invalid file: no sessions array found."));
          return;
        }
        resolve(sessions as Session[]);
      } catch {
        reject(new Error("Invalid JSON file."));
      }
    };
    reader.onerror = () => reject(new Error("Could not read file."));
    reader.readAsText(file);
  });
}

export function mergeSessions(existing: Session[], incoming: Session[]): Session[] {
  const byId = new Map(existing.map((s) => [s.id, s]));
  for (const s of incoming) byId.set(s.id, s);
  return Array.from(byId.values()).sort((a, b) => a.createdAt - b.createdAt);
}