import type { ChartThemeDef } from "@/lib/types";

const LOCAL_KEY = "replay-pro.chart-themes";

/** Chart themes are kept in the browser only - no server-side disk writes. */
export function loadThemesFromBrowser(): ChartThemeDef[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(LOCAL_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveThemesToBrowser(themes: ChartThemeDef[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(LOCAL_KEY, JSON.stringify(themes));
  } catch {
    // ignore
  }
}
