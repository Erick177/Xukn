import type {
  Bar,
  Session,
  Position,
  PendingOrder,
  JournalEntry,
  OrderSide,
  OrderKind,
} from "@/lib/types";
import { useReplayStore } from "@/lib/store";
declare const TradingView: any;
interface TradeOrderInput {
  type: OrderSide;
  kind: OrderKind;
  entryPrice?: number;
  sl: number;
  rr: number;
  riskUsd: number;
  note: string;
}

interface RiskRewardDrawing {
  tradeType: OrderSide;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  executionType: "market" | "limit" | "stop";
  currentPrice: number;
}

interface TvWidget {
  onChartReady: (cb: () => void) => void;
  activeChart: () => TvChartApi;
  changeTheme?: (theme: "Dark" | "Light") => void;
  remove?: () => void;
  chart: () => TvChartApi;
  createButton: (opts?: { align?: string; useTradingViewStyle?: boolean }) => HTMLElement;
  createDropdown: (opts: { title: string; tooltip: string; items: Array<{ title: string; onSelect: () => void }> }) => void;
  headerReady: () => Promise<void>;
  applyOverrides: (overrides: Record<string, unknown>) => void;
  saveChartToServer: (
    onSuccess?: (result?: unknown) => void,
    onError?: (err: unknown) => void,
    opts?: { defaultChartName?: string }
  ) => void;
  loadChartFromServer: (chartData: unknown) => void;
  getSavedCharts: (cb: (charts: unknown[]) => void) => void;
  getAllCharts: () => Promise<unknown[]>;
  save: (cb: (json: string) => void, opts?: { includeDrawings?: boolean }) => void;
  subscribe: (event: string, cb: (...args: unknown[]) => void) => void;
  unsubscribe: (event: string, cb: (...args: unknown[]) => void) => void;
}

interface TvChartApi {
  applyOverrides: (overrides: Record<string, unknown>) => void;
  resetData: () => void;
  onIntervalChanged: () => { subscribe: (obj: unknown, cb: (interval: string) => void) => void };
  selection: () => { allSources: () => string[] };
  getShapeById: (id: string) => TvShapeApi | null;
  createMultipointShape: (points: Array<{ time: number; price: number }>, opts: { shape: string }) => string | null;
  removeEntity: (id: string) => void;
  createOrderLine: () => TvOrderLine;
}

interface TvShapeApi {
  getProperties: () => Record<string, number | string>;
  getPoints: () => Array<{ price: number; time?: number }>;
  _source?: { toolname?: string };
}

interface TvOrderLine {
  setPrice: (price: number) => void;
  setText: (text: string) => void;
  setLineStyle: (style: number) => void;
  setLineColor: (color: string) => void;
  setQuantity: (qty: string) => void;
  onMove: (cb: () => void) => void;
  onCancel: (cb: () => void) => void;
  remove: () => void;
  getPrice: () => number;
}

interface EngineState {
  session: Session | null;
  bars: Bar[];
  buffer: Bar[];
  cursorTime: number | null;
  ended: boolean;
  fetching: boolean;
  timeframe: number;
  aggregated: Bar[];
  replayCursor: number;
  currentLiveBar: Bar | null;
  isPlaying: boolean;
  speedMs: number;
  widget: TvWidget | null;
  container: HTMLElement | null;
  realtimeCallback: ((bar: Bar) => void) | null;
  listenerId: string | null;
  positions: Position[];
  pendingOrders: PendingOrder[];
  journal: JournalEntry[];
  balance: number;
  initialBalance: number;
  priceDecimals: number;
  symbol: string;
  shapeLines: Record<number, { entryLine: TvOrderLine; stopLossLine: TvOrderLine; takeProfitLine: TvOrderLine; partialLines: TvOrderLine[] }>;
  lastUIRenderTime: number;
  consecutiveEmptyFetches: number;
  maxHistory: number;
  trimBatch: number;
  dataFile: string | null;
  nextOrderId: number;
}

function buildDatafeed(engine: ReplayEngine): unknown {
  return {
    onReady: (cb: (config: unknown) => void) => {
      setTimeout(() => {
        cb({
          supported_resolutions: ["1", "5", "15", "60", "240", "1440"],
          exchanges: [{ value: "Traders Casa", name: "Traders Casa", desc: "Traders Casa" }],
          symbols_types: [{ name: "All", value: "All" }],
        });
      }, 0);
    },
    searchSymbols: (_userInput: string, _exchange: string, _symbolType: string, onResult: (res: unknown[]) => void) => {
      onResult([]);
    },
    resolveSymbol: (_symbolName: string, onResolve: (info: unknown) => void) => {
      const engineState = engine.getState();
      setTimeout(() => {
        try {
          onResolve({
            name: engineState.symbol,
            ticker: engineState.symbol,
            description: `${engineState.symbol} Replay`,
            type: "forex",
            session: "24x7",
            timezone: "Etc/UTC",
            exchange: "LOCAL",
            minmov: 1,
            pricescale: Math.pow(10, engineState.priceDecimals),
            has_intraday: true,
            supported_resolutions: ["1", "5", "15", "60", "240", "1440"],
            data_status: "streaming",
          });
        } catch (err) {
          console.error("Error in resolveSymbol:", err);
        }
      }, 0);
    },
    getBars: (
      _symbolInfo: unknown,
      _resolution: string,
      periodParams: { firstDataRequest: boolean; from: number; to: number },
      onHistory: (bars: Bar[], meta: { noData: boolean }) => void
    ) => {
      const state = engine.getState();
      
      if (!state.aggregated || state.aggregated.length === 0) {
        onHistory([], { noData: true });
        return;
      }
      
      const from = periodParams.from || 0;
      const to = periodParams.to || Date.now() / 1000;
      
      const filtered = state.aggregated.filter(
        bar => bar.time >= from && bar.time <= to
      );
      
      const maxBars = 5000;
      const limitedBars = filtered.slice(-maxBars);
      
      if (limitedBars.length > 0) {
        const formattedBars = limitedBars.map(bar => ({
          time: Math.floor(bar.time),
          open: Number(bar.open.toFixed(8)),
          high: Number(bar.high.toFixed(8)),
          low: Number(bar.low.toFixed(8)),
          close: Number(bar.close.toFixed(8)),
          volume: Number((bar.volume || 0).toFixed(2))
        }));
        onHistory(formattedBars, { noData: false });
      } else if (state.aggregated.length > 0) {
        const lastBar = state.aggregated[state.aggregated.length - 1];
        onHistory([{
          time: Math.floor(lastBar.time),
          open: Number(lastBar.open.toFixed(8)),
          high: Number(lastBar.high.toFixed(8)),
          low: Number(lastBar.low.toFixed(8)),
          close: Number(lastBar.close.toFixed(8)),
          volume: Number((lastBar.volume || 0).toFixed(2))
        }], { noData: false });
      } else {
        onHistory([], { noData: true });
      }
    },
    subscribeBars: (
      _symbolInfo: unknown,
      _resolution: string,
      onRealtime: (bar: Bar) => void,
      listenerId: string
    ) => {
      engine.setRealtimeCallback(onRealtime);
      engine.setListenerId(listenerId);
    },
    unsubscribeBars: (listenerId: string) => {
      if (engine.getState().listenerId === listenerId) {
        engine.setRealtimeCallback(null);
      }
    },
  };
}

export class ReplayEngine {
  private state: EngineState;
  private playInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.state = {
      session: null,
      bars: [],
      buffer: [],
      cursorTime: null,
      ended: false,
      fetching: false,
      timeframe: 1,
      aggregated: [],
      replayCursor: 0,
      currentLiveBar: null,
      isPlaying: false,
      speedMs: 500,
      widget: null,
      container: null,
      realtimeCallback: null,
      listenerId: null,
      positions: [],
      pendingOrders: [],
      journal: [],
      balance: 0,
      initialBalance: 0,
      priceDecimals: 5,
      symbol: "SIMULATION",
      shapeLines: {},
      lastUIRenderTime: 0,
      consecutiveEmptyFetches: 0,
      maxHistory: 50000,
      trimBatch: 1000,
      dataFile: null,
      nextOrderId: 1,
    };
  }

  attachContainer(container: HTMLElement | null) {
    this.state.container = container;
    if (container && !this.state.widget) {
      this.createWidget();
    }
  }

  getWidget(): TvWidget | null {
    return this.state.widget;
  }

  getState() {
    return this.state;
  }

  setRealtimeCallback(cb: ((bar: Bar) => void) | null) {
    this.state.realtimeCallback = cb;
  }

  setListenerId(id: string | null) {
    this.state.listenerId = id;
  }

  async loadSession(session: Session) {
    this.togglePlay(false);

    this.state.session = session;
    this.state.symbol = session.symbol || "SIMULATION";
    this.state.priceDecimals = session.priceDecimals || 5;
    this.state.initialBalance = session.initialBalance || 1000;
    this.state.balance = session.currentBalance || session.initialBalance || 1000;
    this.state.journal = session.tradeJournal || [];
    this.state.positions = session.positions || [];
    this.state.pendingOrders = session.pendingOrders || [];
    this.state.timeframe = session.timeframe || 1;
    this.state.dataFile = session.fileName || null;

    this.state.bars = [];
    this.state.buffer = [];
    this.state.aggregated = [];
    this.state.replayCursor = 0;
    this.state.currentLiveBar = null;
    this.state.ended = false;
    this.state.fetching = false;
    this.state.consecutiveEmptyFetches = 0;
    this.state.shapeLines = {};
    this.state.nextOrderId = 1;

    let startTime = session.currentTimestamp || session.startDate;
    if (typeof startTime === "string") {
      startTime = new Date(startTime).getTime();
    } else {
      startTime = Number(startTime) || Date.now();
    }
    this.state.cursorTime = startTime;

    await this.fetchInitialData(startTime);
    this.syncStore();
    this.createWidget();
  }

  private async fetchInitialData(fromTime: number) {
    const desired = 10000;
    const chunkSize = 5000;
    let allBars: Bar[] = [];
    let fetchFrom = Math.max(0, fromTime - desired * 60000);

    while (allBars.length < desired) {
      const chunk = await this.fetchBars(fetchFrom);
      if (chunk.length === 0) break;
      const filtered = chunk.filter(b => allBars.length === 0 || b.time > allBars[allBars.length - 1].time);
      if (filtered.length === 0) break;
      allBars = allBars.concat(filtered);
      const last = filtered[filtered.length - 1].time;
      if (last >= fromTime) break;
      if (chunk.length < chunkSize) break;
      fetchFrom = last + 60000;
    }

    if (allBars.length > 0) {
      let consume = 0;
      for (let i = 0; i < allBars.length; i++) {
        if (allBars[i].time > fromTime) break;
        consume++;
      }
      this.state.buffer = allBars;
      this.advanceDataEngine(Math.max(consume, 1));
    } else {
      this.state.cursorTime = fromTime;
      if (this.state.aggregated.length === 0) {
        const now = Date.now();
        this.state.aggregated = [{
          time: now,
          open: 100,
          high: 101,
          low: 99,
          close: 100,
          volume: 0
        }];
        this.state.currentLiveBar = this.state.aggregated[0];
        this.state.replayCursor = 1;
      }
    }
  }

  private async fetchBars(fromTime: number): Promise<Bar[]> {
    if (!this.state.dataFile) return [];
    try {
      const res = await fetch(`/api/bars?file=${this.state.dataFile}&from=${fromTime}&resolution=1&countBack=5000`);
      if (!res.ok) return [];
      const data = await res.json();
      if (Array.isArray(data)) return data;
      if (data.bars && Array.isArray(data.bars)) return data.bars;
      return [];
    } catch {
      return [];
    }
  }

  private advanceDataEngine(steps: number): Bar[] {
    const produced: Bar[] = [];
    const MINUTE_MS = 60000;
    const MAX_STEPS = 1000;
    const actualSteps = Math.min(steps, MAX_STEPS);

    if (this.state.buffer.length === 0) {
      if (!this.state.fetching && !this.state.ended) this.refillBuffer();
      return produced;
    }

    for (let s = 0; s < actualSteps; s++) {
      if (this.state.buffer.length === 0) {
        if (!this.state.fetching && !this.state.ended) this.refillBuffer();
        break;
      }

      let baseBar = this.state.buffer.shift();
      if (!baseBar) break;

      if (this.state.cursorTime === null) {
        this.state.cursorTime = baseBar.time;
      }

      const expected = this.state.cursorTime + MINUTE_MS;
      const diff = baseBar.time - expected;

      if (diff > 0) {
        const missing = Math.floor(diff / MINUTE_MS);
        if (missing > 0 && missing <= 10) {
          const padPrice = this.state.currentLiveBar ? this.state.currentLiveBar.close : baseBar.open;
          const pads: Bar[] = [];
          for (let i = 0; i < missing; i++) {
            const t = expected + i * MINUTE_MS;
            if (t < baseBar.time) {
              pads.push({ time: t, open: padPrice, high: padPrice, low: padPrice, close: padPrice, volume: 0 });
            }
          }
          if (pads.length > 0) {
            this.state.buffer.unshift(...pads, baseBar);
            baseBar = this.state.buffer.shift()!;
          }
        } else if (missing > 10) {
          this.state.cursorTime = baseBar.time - MINUTE_MS;
        }
      }

      if (this.state.currentLiveBar && baseBar.time <= this.state.currentLiveBar.time) {
        if (baseBar.volume !== 0 && baseBar.time > this.state.cursorTime) {
          this.state.cursorTime = baseBar.time;
        }
        continue;
      }

      this.state.cursorTime = baseBar.time;

      if (!this.state.bars.length || this.state.bars[this.state.bars.length - 1].time < baseBar.time) {
        this.state.bars.push({ ...baseBar });
      }

      const tfMs = this.state.timeframe * MINUTE_MS;
      const bucket = Math.floor(baseBar.time / tfMs) * tfMs;

      if (!this.state.currentLiveBar || this.state.currentLiveBar.time !== bucket) {
        this.state.currentLiveBar = {
          time: bucket,
          open: baseBar.open,
          high: baseBar.high,
          low: baseBar.low,
          close: baseBar.close,
          volume: baseBar.volume,
        };
        this.state.aggregated.push(this.state.currentLiveBar);
      } else {
        this.state.currentLiveBar.high = Math.max(this.state.currentLiveBar.high, baseBar.high);
        this.state.currentLiveBar.low = Math.min(this.state.currentLiveBar.low, baseBar.low);
        this.state.currentLiveBar.close = baseBar.close;
        this.state.currentLiveBar.volume += baseBar.volume;
        this.state.aggregated[this.state.aggregated.length - 1] = this.state.currentLiveBar;
      }

      this.state.replayCursor = this.state.aggregated.length;
      produced.push(this.state.currentLiveBar);

      if (this.state.aggregated.length > this.state.maxHistory + this.state.trimBatch) {
        const remove = this.state.aggregated.length - this.state.maxHistory;
        this.state.aggregated.splice(0, remove);
        this.state.replayCursor -= remove;
      }
      if (this.state.bars.length > this.state.maxHistory + this.state.trimBatch) {
        this.state.bars.splice(0, this.state.bars.length - this.state.maxHistory);
      }

      if (this.state.buffer.length < 200 && !this.state.fetching && !this.state.ended) {
        this.refillBuffer();
      }
    }

    this.syncStore();
    return produced;
  }

  private refillBuffer() {
    if (this.state.fetching || this.state.ended) return;
    this.state.fetching = true;

    const queryTime = this.state.cursorTime ?? 0;
    fetch(`/api/bars?file=${this.state.dataFile}&from=${queryTime}&resolution=1&countBack=5000`)
      .then(res => res.json())
      .then((data: Bar[]) => {
        if (!Array.isArray(data)) data = [];
        data.sort((a, b) => a.time - b.time);
        if (data.length === 0) {
          this.state.consecutiveEmptyFetches++;
          if (this.state.consecutiveEmptyFetches >= 3) {
            this.state.ended = true;
          }
        } else {
          this.state.consecutiveEmptyFetches = 0;
          const last = this.state.buffer.length ? this.state.buffer[this.state.buffer.length - 1].time : 0;
          const fresh = data.filter(b => b.time > last);
          this.state.buffer.push(...fresh);
        }
      })
      .catch(() => {
        this.state.consecutiveEmptyFetches++;
      })
      .finally(() => {
        this.state.fetching = false;
      });
  }

  stepForward(steps: number = 1) {
    if (this.state.ended && this.state.buffer.length === 0) {
      this.togglePlay(false);
      return;
    }

    const produced = this.advanceDataEngine(steps);

    if (produced.length > 0 && this.state.realtimeCallback) {
      produced.forEach(bar => this.state.realtimeCallback!(bar));
    }

    produced.forEach(bar => this.checkExecution(bar));

    const now = Date.now();
    const isBulk = steps > 5;
    if (!this.state.isPlaying || isBulk || now - this.state.lastUIRenderTime >= 500) {
      this.state.lastUIRenderTime = now;
      this.syncStore();
    }

    this.syncStore();
  }

  togglePlay(force?: boolean) {
    this.state.isPlaying = force !== undefined ? force : !this.state.isPlaying;
    
    const store = useReplayStore.getState();
    store.setPlaying(this.state.isPlaying);

    if (this.state.isPlaying) {
      if (this.playInterval) {
        clearInterval(this.playInterval);
      }
      this.playInterval = setInterval(
        () => this.stepForward(1),
        this.state.speedMs
      );
    } else {
      if (this.playInterval) {
        clearInterval(this.playInterval);
        this.playInterval = null;
      }
    }
    
    this.syncStore();
  }

  setSpeed(ms: number) {
    const clampedMs = Math.max(30, Math.min(1000, ms));
    this.state.speedMs = clampedMs;
    
    const store = useReplayStore.getState();
    store.setSpeedMs(clampedMs);

    if (this.state.isPlaying) {
      if (this.playInterval) {
        clearInterval(this.playInterval);
      }
      this.playInterval = setInterval(
        () => this.stepForward(1),
        clampedMs
      );
    }
  }

  createOrder(input: TradeOrderInput) {
    const currentBar = this.state.aggregated[this.state.aggregated.length - 1];
    if (!currentBar) {
      console.warn("No current bar available");
      return;
    }

    const entryPrice = input.kind === "LIMIT" ? input.entryPrice! : currentBar.close;
    const slPrice = input.sl;
    const rrRatio = input.rr || 2;
    const riskUsd = input.riskUsd || 10;

    if (isNaN(entryPrice) || isNaN(slPrice)) {
      console.warn("Invalid entry or SL price");
      return;
    }

    if ((input.type === "BUY" && slPrice >= entryPrice) || (input.type === "SELL" && slPrice <= entryPrice)) {
      console.warn("Invalid SL for direction");
      return;
    }

    const distance = Math.abs(entryPrice - slPrice);
    const tpPrice = input.type === "BUY" ? entryPrice + distance * rrRatio : entryPrice - distance * rrRatio;
    const size = riskUsd / distance;

    const order: PendingOrder = {
      id: this.state.nextOrderId++,
      type: input.type,
      size,
      entryPrice,
      sl: slPrice,
      tp: tpPrice,
      note: input.note || "",
      riskAmount: riskUsd,
      createdAt: Date.now(),
    };

    if (input.kind === "LIMIT") {
      this.state.pendingOrders.push(order);
      console.log(`Limit order placed: ${order.type} @ ${order.entryPrice}`);
    } else {
      this.state.positions.push({
        id: order.id,
        type: order.type,
        size: order.size,
        entryPrice: order.entryPrice,
        sl: order.sl,
        tp: order.tp,
        note: order.note,
        riskAmount: order.riskAmount,
        entryTime: new Date(currentBar.time).toISOString(),
      });
      console.log(`Market order executed: ${order.type} @ ${order.entryPrice}`);
    }

    this.syncStore();
  }

  cancelPendingOrder(id: number) {
    const idx = this.state.pendingOrders.findIndex(o => o.id === id);
    if (idx >= 0) {
      this.state.pendingOrders.splice(idx, 1);
      this.syncStore();
      console.log(`Pending order ${id} cancelled`);
    }
  }

  closePosition(posId: number, closeSize?: number) {
    const posIdx = this.state.positions.findIndex(p => p.id === posId);
    if (posIdx === -1) {
      console.warn(`Position ${posId} not found`);
      return;
    }

    const pos = this.state.positions[posIdx];
    const currentPrice = this.state.aggregated[this.state.aggregated.length - 1]?.close || pos.entryPrice;

    const sizeToClose = closeSize !== undefined ? Math.min(closeSize, pos.size) : pos.size;
    const pnl = (pos.type === "BUY" ? currentPrice - pos.entryPrice : pos.entryPrice - currentPrice) * sizeToClose;
    this.state.balance += pnl;

    this.state.journal.push({
      id: this.state.journal.length + 1,
      type: pos.type,
      size: sizeToClose.toFixed(4),
      entryPrice: pos.entryPrice.toFixed(this.state.priceDecimals),
      exitPrice: currentPrice.toFixed(this.state.priceDecimals),
      outcome: "MANUAL",
      pnl: pnl.toFixed(2),
      balanceAfter: this.state.balance.toFixed(2),
      note: pos.note || "",
      date: new Date(currentPrice).toISOString(),
    });

    if (sizeToClose >= pos.size) {
      this.state.positions.splice(posIdx, 1);
      console.log(`Position ${posId} closed completely`);
    } else {
      pos.size -= sizeToClose;
      console.log(`Position ${posId} partially closed: ${sizeToClose} units`);
    }

    this.syncStore();
  }

  closeByPercent(posId: number, percent: number) {
    const pos = this.state.positions.find(p => p.id === posId);
    if (!pos) {
      console.warn(`Position ${posId} not found`);
      return;
    }
    
    const sizeToClose = (pos.size * percent) / 100;
    console.log(`Closing ${percent}% of position ${posId}: ${sizeToClose} units`);
    
    if (percent >= 100) {
      this.closePosition(posId);
    } else {
      this.closePosition(posId, sizeToClose);
    }
  }

  applyDetailChanges(posId: number, sl: number, tp: number) {
    const pos = this.state.positions.find(p => p.id === posId);
    if (!pos) {
      console.warn(`Position ${posId} not found`);
      return;
    }
    if (!isNaN(sl)) pos.sl = sl;
    if (!isNaN(tp)) pos.tp = tp;
    this.syncStore();
    console.log(`Position ${posId} updated: SL=${pos.sl}, TP=${pos.tp}`);
  }

  addVolume(posId: number, addSize: number) {
    const pos = this.state.positions.find(p => p.id === posId);
    if (!pos) {
      console.warn(`Position ${posId} not found`);
      return;
    }
    if (addSize <= 0) {
      console.warn("Add size must be positive");
      return;
    }
    
    const currentPrice = this.state.aggregated[this.state.aggregated.length - 1]?.close || pos.entryPrice;
    const newSize = pos.size + addSize;
    pos.entryPrice = (pos.entryPrice * pos.size + currentPrice * addSize) / newSize;
    pos.size = newSize;
    this.syncStore();
    console.log(`Added ${addSize} units to position ${posId}`);
  }

  importFromDrawing(): RiskRewardDrawing | null {
    const widget = this.state.widget;
    if (!widget) return null;

    const chart = widget.activeChart();
    if (!chart) return null;

    let ids: string[];
    try {
      ids = chart.selection().allSources();
    } catch {
      return null;
    }
    if (!ids || ids.length !== 1) return null;

    let shape: TvShapeApi | null;
    try {
      shape = chart.getShapeById(ids[0]);
    } catch {
      return null;
    }
    if (!shape) return null;

    const toolname = shape._source?.toolname;
    if (toolname !== "LineToolRiskRewardLong" && toolname !== "LineToolRiskRewardShort") return null;

    let props: Record<string, number | string>;
    let points: Array<{ price: number; time?: number }>;
    try {
      props = shape.getProperties();
      points = shape.getPoints();
    } catch {
      return null;
    }
    if (!props || !points || !points.length) return null;

    const stopLevel = props.stopLevel as number;
    const profitLevel = props.profitLevel as number;
    if (typeof stopLevel !== "number" || typeof profitLevel !== "number") return null;

    const isLong = toolname === "LineToolRiskRewardLong";
    const direction = isLong ? 1 : -1;
    const scale = Math.pow(10, this.state.priceDecimals);
    const entryPrice = Math.round(points[0].price * scale) / scale;
    const stopLoss = (entryPrice - direction * stopLevel / scale);
    const takeProfit = (entryPrice + direction * profitLevel / scale);

    const currentPrice = this.state.aggregated.length ? this.state.aggregated[this.state.aggregated.length - 1].close : entryPrice;

    let executionType: "market" | "limit" | "stop";
    if (Math.abs(entryPrice - currentPrice) < 1e-9) {
      executionType = "market";
    } else if (isLong) {
      executionType = entryPrice > currentPrice ? "stop" : "limit";
    } else {
      executionType = entryPrice < currentPrice ? "stop" : "limit";
    }

    return {
      tradeType: isLong ? "BUY" : "SELL",
      entryPrice,
      stopLoss,
      takeProfit,
      executionType,
      currentPrice,
    };
  }

  applyChartMode(mode: "dark" | "light") {
    if (this.state.widget && typeof this.state.widget.changeTheme === "function") {
      this.state.widget.changeTheme(mode === "dark" ? "Dark" : "Light");
    }
    document.body.classList.toggle("light-theme", mode === "light");
  }

  private syncStore() {
    const store = useReplayStore.getState();
    store.setBalance(this.state.balance);
    store.setPriceDecimals(this.state.priceDecimals);
    const current = this.state.aggregated[this.state.aggregated.length - 1];
    store.setCurrentPrice(current ? current.close : null);
    store.setCandleLabel(
      current
        ? new Date(current.time).toLocaleString()
        : `${this.state.replayCursor} / ${this.state.aggregated.length}`
    );
    store.setPlaying(this.state.isPlaying);
    store.setSpeedMs(this.state.speedMs);
    store.setPositions(this.state.positions);
    store.setPendingOrders(this.state.pendingOrders);
    store.setJournal(this.state.journal);

    if (this.state.session) {
      const session = { ...this.state.session };
      session.currentBalance = this.state.balance;
      session.currentTimestamp = this.state.cursorTime || session.currentTimestamp;
      session.replayIndex = this.state.replayCursor;
      session.timeframe = this.state.timeframe;
      session.tradeJournal = this.state.journal;
      session.positions = this.state.positions;
      session.pendingOrders = this.state.pendingOrders;
      store.upsertSession(session);
    }
  }

  private checkExecution(bar: Bar) {
    for (let i = this.state.pendingOrders.length - 1; i >= 0; i--) {
      const o = this.state.pendingOrders[i];
      if (bar.low <= o.entryPrice && bar.high >= o.entryPrice) {
        this.state.positions.push({
          id: o.id,
          type: o.type,
          size: o.size,
          entryPrice: o.entryPrice,
          sl: o.sl,
          tp: o.tp,
          note: o.note,
          riskAmount: o.riskAmount,
          entryTime: new Date(bar.time).toISOString(),
        });
        this.state.pendingOrders.splice(i, 1);
        console.log(`Pending order ${o.id} executed at ${o.entryPrice}`);
      }
    }

    for (let i = this.state.positions.length - 1; i >= 0; i--) {
      const pos = this.state.positions[i];
      let hit = false;
      let outcome: "TP" | "SL" = "TP";
      let execPrice = 0;

      if (pos.type === "BUY") {
        if (bar.low <= pos.sl) { hit = true; outcome = "SL"; execPrice = pos.sl; }
        else if (bar.high >= pos.tp) { hit = true; outcome = "TP"; execPrice = pos.tp; }
      } else {
        if (bar.high >= pos.sl) { hit = true; outcome = "SL"; execPrice = pos.sl; }
        else if (bar.low <= pos.tp) { hit = true; outcome = "TP"; execPrice = pos.tp; }
      }

      if (hit) {
        const pnl = (pos.type === "BUY" ? execPrice - pos.entryPrice : pos.entryPrice - execPrice) * pos.size;
        this.state.balance += pnl;
        this.state.journal.push({
          id: this.state.journal.length + 1,
          type: pos.type,
          size: pos.size.toFixed(4),
          entryPrice: pos.entryPrice.toFixed(this.state.priceDecimals),
          exitPrice: execPrice.toFixed(this.state.priceDecimals),
          outcome,
          pnl: pnl.toFixed(2),
          balanceAfter: this.state.balance.toFixed(2),
          note: pos.note || "",
          date: new Date(bar.time).toISOString(),
        });
        this.state.positions.splice(i, 1);
        console.log(`Position ${pos.id} closed: ${outcome} @ ${execPrice}, PnL: $${pnl.toFixed(2)}`);
      }
    }
  }

  private createWidget() {
    if (!this.state.container) return;

    if (this.state.widget) {
      try { this.state.widget.remove?.(); } catch {}
      this.state.widget = null;
    }

    const container = this.state.container;
    container.innerHTML = "";

    const datafeed = buildDatafeed(this);

    if (typeof TradingView === "undefined" || !TradingView.widget) {
      container.innerHTML = `<div style="padding:20px;color:var(--text-muted)">TradingView library not loaded</div>`;
      return;
    }

    const widget = new TradingView.widget({
      container: container,
      library_path: "/charting_library/",
      datafeed,
      symbol: this.state.symbol,
      interval: this.state.timeframe.toString(),
      fullscreen: false,
      autosize: true,
      locale: "en",
      disabled_features: ["header_symbol_search", "header_compare"],
      enabled_features: ["side_toolbar_in_popup"],
      overrides: {
        "mainSeriesProperties.style": 1,
        "mainSeriesProperties.showCountdown": true,
      },
    });

    this.state.widget = widget as unknown as TvWidget;

    widget.onChartReady(() => {
      const chart = widget.activeChart();
      chart.onIntervalChanged().subscribe(null, (interval: string) => {
        const newTF = parseInt(interval) || 1;
        if (this.state.timeframe !== newTF) {
          this.state.timeframe = newTF;
          this.rebuildAggregation();
          this.syncStore();
        }
      });
    });
  }

  private rebuildAggregation() {
    const tfMs = this.state.timeframe * 60000;
    const agg: Bar[] = [];
    let current: Bar | null = null;

    for (const b of this.state.bars) {
      const bucket = Math.floor(b.time / tfMs) * tfMs;
      if (!current || current.time !== bucket) {
        if (current) agg.push(current);
        current = { time: bucket, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume };
      } else {
        current.high = Math.max(current.high, b.high);
        current.low = Math.min(current.low, b.low);
        current.close = b.close;
        current.volume += b.volume;
      }
    }
    if (current) agg.push(current);

    this.state.aggregated = agg;
    this.state.replayCursor = agg.length;
    this.state.currentLiveBar = agg[agg.length - 1] || null;
  }

  reset() {
    this.togglePlay(false);
    this.state.session = null;
    this.state.bars = [];
    this.state.buffer = [];
    this.state.aggregated = [];
    this.state.replayCursor = 0;
    this.state.currentLiveBar = null;
    this.state.ended = false;
    this.state.fetching = false;
    this.state.positions = [];
    this.state.pendingOrders = [];
    this.state.journal = [];
    this.state.balance = 0;
    this.state.shapeLines = {};
    this.state.nextOrderId = 1;
    this.state.cursorTime = null;
    this.state.dataFile = null;
    this.syncStore();
    console.log("Engine reset");
  }
}

export const replayEngine = new ReplayEngine();