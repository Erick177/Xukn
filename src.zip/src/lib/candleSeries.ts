import { Bar, DecodedSeries } from "./xbin/constants";

export class CandleSeries {
  readonly symbol: string;
  readonly resolution: string;
  readonly times: Float64Array;
  readonly open: Float32Array;
  readonly high: Float32Array;
  readonly low: Float32Array;
  readonly close: Float32Array;
  readonly volume: Float32Array | null;

  constructor(data: {
    symbol: string;
    resolution: string;
    times: Float64Array;
    open: Float32Array;
    high: Float32Array;
    low: Float32Array;
    close: Float32Array;
    volume: Float32Array | null;
  }) {
    this.symbol = data.symbol;
    this.resolution = data.resolution;
    this.times = data.times;
    this.open = data.open;
    this.high = data.high;
    this.low = data.low;
    this.close = data.close;
    this.volume = data.volume;
  }

  static fromDecoded(d: DecodedSeries): CandleSeries {
    return new CandleSeries(d);
  }

  get length(): number {
    return this.times.length;
  }

  get byteLength(): number {
    return (
      this.times.byteLength +
      this.open.byteLength +
      this.high.byteLength +
      this.low.byteLength +
      this.close.byteLength +
      (this.volume ? this.volume.byteLength : 0)
    );
  }

  get(i: number): Bar {
    return {
      time: this.times[i],
      open: this.open[i],
      high: this.high[i],
      low: this.low[i],
      close: this.close[i],
      volume: this.volume ? this.volume[i] : 0,
    };
  }

  lowerBound(t: number): number {
    let lo = 0;
    let hi = this.times.length;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (this.times[mid] < t) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }

  upperBound(t: number): number {
    let lo = 0;
    let hi = this.times.length;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (this.times[mid] <= t) lo = mid + 1;
      else hi = mid;
    }
    return lo - 1;
  }

  toBars(fromSec: number, toSec: number, limit: number = 5000): Bar[] {
    if (this.length === 0) return [];
    
    const startIdx = Math.max(0, this.lowerBound(fromSec));
    const endIdx = Math.min(this.length - 1, this.upperBound(toSec));
    
    if (startIdx > endIdx) return [];
    
    const count = Math.min(endIdx - startIdx + 1, limit);
    const out: Bar[] = new Array(count);
    
    for (let i = 0; i < count; i++) {
      const idx = endIdx - count + 1 + i;
      const bar = this.get(idx);
      out[i] = {
        time: Math.floor(bar.time),
        open: Number(bar.open.toFixed(8)),
        high: Number(bar.high.toFixed(8)),
        low: Number(bar.low.toFixed(8)),
        close: Number(bar.close.toFixed(8)),
        volume: Number(bar.volume.toFixed(2))
      };
    }
    
    return out;
  }

  get firstTime(): number | null {
    return this.length > 0 ? this.times[0] : null;
  }

  get lastTime(): number | null {
    return this.length > 0 ? this.times[this.length - 1] : null;
  }
}