import { create } from "zustand";
import type {
  ChartThemeDef,
  JournalEntry,
  PendingOrder,
  Position,
  Session,
} from "@/lib/types";

export type ChartMode = "dark" | "light";

interface ToastMessage {
  id: number;
  text: string;
  kind: "success" | "error" | "warning" | "info";
}

interface ReplayState {
  sessions: Session[];
  activeSessionId: number | null;

  dashboardOpen: boolean;
  tradePanelOpen: boolean;
  themeManagerOpen: boolean;
  positionDetailId: number | null;
  controlBarCollapsed: boolean;

  libraryMissing: boolean;

  chartMode: ChartMode;
  themes: ChartThemeDef[];

  balance: number;
  priceDecimals: number;
  currentPrice: number | null;
  candleLabel: string;
  playing: boolean;
  speedMs: number;
  stepCount: number;
  positions: Position[];
  pendingOrders: PendingOrder[];
  journal: JournalEntry[];

  toasts: ToastMessage[];

  orderKind: "MARKET" | "LIMIT";
  orderEntryPrice: string;
  orderSl: string;
  orderRr: string;
  orderRiskUsd: string;
  orderNote: string;
  setOrderKind: (v: "MARKET" | "LIMIT") => void;
  setOrderEntryPrice: (v: string) => void;
  setOrderSl: (v: string) => void;
  setOrderRr: (v: string) => void;
  setOrderRiskUsd: (v: string) => void;
  setOrderNote: (v: string) => void;

  setSessions: (sessions: Session[]) => void;
  upsertSession: (session: Session) => void;
  removeSession: (id: number) => void;
  setActiveSessionId: (id: number | null) => void;
  patchActiveSession: (patch: Partial<Session>) => void;

  openDashboard: () => void;
  closeDashboard: () => void;
  toggleTradePanel: () => void;
  toggleThemeManager: (force?: boolean) => void;
  toggleControlBar: () => void;
  setPositionDetailId: (id: number | null) => void;

  setLibraryMissing: (v: boolean) => void;
  setChartMode: (mode: ChartMode) => void;
  setThemes: (themes: ChartThemeDef[]) => void;

  setBalance: (v: number) => void;
  setPriceDecimals: (v: number) => void;
  setCurrentPrice: (v: number | null) => void;
  setCandleLabel: (v: string) => void;
  setPlaying: (v: boolean) => void;
  setSpeedMs: (v: number) => void;
  setStepCount: (v: number) => void;
  setPositions: (v: Position[]) => void;
  setPendingOrders: (v: PendingOrder[]) => void;
  setJournal: (v: JournalEntry[]) => void;

  pushToast: (text: string, kind?: ToastMessage["kind"]) => void;
  dismissToast: (id: number) => void;
}

export const useReplayStore = create<ReplayState>((set, get) => ({
  sessions: [],
  activeSessionId: null,

  dashboardOpen: true,
  tradePanelOpen: false,
  themeManagerOpen: false,
  positionDetailId: null,
  controlBarCollapsed: false,

  libraryMissing: false,

  chartMode: "dark",
  themes: [],

  balance: 0,
  priceDecimals: 5,
  currentPrice: null,
  candleLabel: "0 / 0",
  playing: false,
  speedMs: 500,
  stepCount: 1,
  positions: [],
  pendingOrders: [],
  journal: [],

  toasts: [],

  orderKind: "MARKET",
  orderEntryPrice: "",
  orderSl: "",
  orderRr: "2",
  orderRiskUsd: "10",
  orderNote: "",
  setOrderKind: (v) => set({ orderKind: v }),
  setOrderEntryPrice: (v) => set({ orderEntryPrice: v }),
  setOrderSl: (v) => set({ orderSl: v }),
  setOrderRr: (v) => set({ orderRr: v }),
  setOrderRiskUsd: (v) => set({ orderRiskUsd: v }),
  setOrderNote: (v) => set({ orderNote: v }),

  setSessions: (sessions) => set({ sessions }),
  upsertSession: (session) =>
    set((state) => {
      const idx = state.sessions.findIndex((s) => s.id === session.id);
      const next = [...state.sessions];
      if (idx >= 0) next[idx] = session;
      else next.push(session);
      return { sessions: next };
    }),
  removeSession: (id) =>
    set((state) => ({
      sessions: state.sessions.filter((s) => s.id !== id),
      activeSessionId: state.activeSessionId === id ? null : state.activeSessionId,
    })),
  setActiveSessionId: (id) => set({ activeSessionId: id }),
  patchActiveSession: (patch) => {
    const { activeSessionId, sessions } = get();
    if (activeSessionId === null) return;
    const next = sessions.map((s) => (s.id === activeSessionId ? { ...s, ...patch } : s));
    set({ sessions: next });
  },

  openDashboard: () => set({ dashboardOpen: true }),
  closeDashboard: () => set({ dashboardOpen: false }),
  toggleTradePanel: () => set((state) => ({ tradePanelOpen: !state.tradePanelOpen })),
  toggleThemeManager: (force) =>
    set((state) => ({ themeManagerOpen: force !== undefined ? force : !state.themeManagerOpen })),
  toggleControlBar: () => set((state) => ({ controlBarCollapsed: !state.controlBarCollapsed })),
  setPositionDetailId: (id) => set({ positionDetailId: id }),

  setLibraryMissing: (v) => set({ libraryMissing: v }),
  setChartMode: (mode) => set({ chartMode: mode }),
  setThemes: (themes) => set({ themes }),

  setBalance: (v) => set({ balance: v }),
  setPriceDecimals: (v) => set({ priceDecimals: v }),
  setCurrentPrice: (v) => set({ currentPrice: v }),
  setCandleLabel: (v) => set({ candleLabel: v }),
  setPlaying: (v) => set({ playing: v }),
  setSpeedMs: (v) => set({ speedMs: v }),
  setStepCount: (v) => set({ stepCount: v }),
  setPositions: (v) => set({ positions: v }),
  setPendingOrders: (v) => set({ pendingOrders: v }),
  setJournal: (v) => set({ journal: v }),

  pushToast: (text, kind = "info") =>
    set((state) => ({ toasts: [...state.toasts, { id: Date.now() + Math.random(), text, kind }] })),
  dismissToast: (id) => set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),
}));