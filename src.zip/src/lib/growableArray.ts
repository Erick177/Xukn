/**
 * Small helper used by the CSV loader to build typed arrays without knowing
 * the row count up-front, while avoiding pushing values into a plain JS
 * array (which would box every number and cost far more memory/GC time).
 */
export class GrowableFloat64Array {
  private buf: Float64Array;
  private len = 0;

  constructor(initialCapacity = 1024) {
    this.buf = new Float64Array(initialCapacity);
  }

  push(value: number): void {
    if (this.len >= this.buf.length) this.grow();
    this.buf[this.len++] = value;
  }

  private grow(): void {
    const next = new Float64Array(this.buf.length * 2);
    next.set(this.buf);
    this.buf = next;
  }

  toArray(): Float64Array {
    return this.buf.subarray(0, this.len);
  }

  get length(): number {
    return this.len;
  }
}

export class GrowableFloat32Array {
  private buf: Float32Array;
  private len = 0;

  constructor(initialCapacity = 1024) {
    this.buf = new Float32Array(initialCapacity);
  }

  push(value: number): void {
    if (this.len >= this.buf.length) this.grow();
    this.buf[this.len++] = value;
  }

  private grow(): void {
    const next = new Float32Array(this.buf.length * 2);
    next.set(this.buf);
    this.buf = next;
  }

  toArray(): Float32Array {
    return this.buf.subarray(0, this.len);
  }

  get length(): number {
    return this.len;
  }
}
