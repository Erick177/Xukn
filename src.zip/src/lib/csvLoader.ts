/**
 * Fast, low-allocation CSV loader kept for backward compatibility with
 * existing heavy CSV files. It streams the response body, avoids
 * String.split()/regex per line, and writes straight into typed arrays via
 * GrowableFloat64Array/GrowableFloat32Array instead of building an
 * intermediate array of row objects.
 *
 * Expected columns (header optional, auto-detected): time,open,high,low,close,volume
 * `time` may be a unix timestamp in seconds or milliseconds (auto-detected).
 */
import { CandleSeries } from "./candleSeries";
import { GrowableFloat32Array, GrowableFloat64Array } from "./growableArray";

export interface CsvLoadOptions {
  symbol?: string;
  resolution?: string;
  delimiter?: string; // default ','
  hasHeader?: "auto" | boolean;
}

function parseLine(
  line: string,
  delimiter: string,
  times: GrowableFloat64Array,
  open: GrowableFloat32Array,
  high: GrowableFloat32Array,
  low: GrowableFloat32Array,
  close: GrowableFloat32Array,
  volume: GrowableFloat32Array,
): boolean {
  if (line.length === 0) return false;
  let start = 0;
  let col = 0;
  let t = 0;
  let o = 0,
    h = 0,
    l = 0,
    c = 0,
    v = 0;
  for (let i = 0; i <= line.length; i++) {
    if (i === line.length || line[i] === delimiter) {
      const field = line.slice(start, i);
      switch (col) {
        case 0:
          t = Number(field);
          break;
        case 1:
          o = Number(field);
          break;
        case 2:
          h = Number(field);
          break;
        case 3:
          l = Number(field);
          break;
        case 4:
          c = Number(field);
          break;
        case 5:
          v = Number(field);
          break;
      }
      col++;
      start = i + 1;
    }
  }
  if (col < 5 || Number.isNaN(t) || Number.isNaN(o)) return false;
  // auto-detect ms vs sec timestamps
  const timeSec = t > 1e12 ? t / 1000 : t;
  times.push(timeSec);
  open.push(o);
  high.push(h);
  low.push(l);
  close.push(c);
  volume.push(col > 5 ? v : 0);
  return true;
}

/** Parses a full CSV string synchronously. Useful for small/medium files or already-fetched text. */
export function parseCsv(text: string, opts: CsvLoadOptions = {}): CandleSeries {
  const delimiter = opts.delimiter ?? ",";
  const times = new GrowableFloat64Array(4096);
  const open = new GrowableFloat32Array(4096);
  const high = new GrowableFloat32Array(4096);
  const low = new GrowableFloat32Array(4096);
  const close = new GrowableFloat32Array(4096);
  const volume = new GrowableFloat32Array(4096);

  let lineStart = 0;
  let firstLine = true;
  const n = text.length;
  for (let i = 0; i <= n; i++) {
    if (i === n || text.charCodeAt(i) === 10) {
      let end = i;
      if (end > lineStart && text.charCodeAt(end - 1) === 13) end--; // strip \r
      const line = text.slice(lineStart, end);
      lineStart = i + 1;
      if (firstLine) {
        firstLine = false;
        const looksNumeric = /^-?\d/.test(line.trim());
        if (opts.hasHeader === true || (opts.hasHeader !== false && !looksNumeric)) {
          continue; // skip header row
        }
      }
      parseLine(line, delimiter, times, open, high, low, close, volume);
    }
  }

  const hasVolume = volume.toArray().some((v) => v !== 0);

  return new CandleSeries({
    symbol: opts.symbol ?? "",
    resolution: opts.resolution ?? "",
    times: times.toArray(),
    open: open.toArray(),
    high: high.toArray(),
    low: low.toArray(),
    close: close.toArray(),
    volume: hasVolume ? volume.toArray() : null,
  });
}

/** Streams a CSV file over HTTP and parses it incrementally (keeps memory flat regardless of file size). */
export async function loadCsvSeries(url: string, opts: CsvLoadOptions = {}): Promise<CandleSeries> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch CSV: ${res.status} ${res.statusText}`);

  const delimiter = opts.delimiter ?? ",";
  const times = new GrowableFloat64Array(65536);
  const open = new GrowableFloat32Array(65536);
  const high = new GrowableFloat32Array(65536);
  const low = new GrowableFloat32Array(65536);
  const close = new GrowableFloat32Array(65536);
  const volume = new GrowableFloat32Array(65536);

  if (!res.body) {
    const text = await res.text();
    return parseCsv(text, opts);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let pending = "";
  let firstLine = true;
  let rowIndex = 0;

  const handleChunk = (chunk: string) => {
    pending += chunk;
    let nl: number;
    while ((nl = pending.indexOf("\n")) !== -1) {
      let end = nl;
      if (end > 0 && pending.charCodeAt(end - 1) === 13) end--;
      const line = pending.slice(0, end);
      pending = pending.slice(nl + 1);
      if (firstLine) {
        firstLine = false;
        const looksNumeric = /^-?\d/.test(line.trim());
        if (opts.hasHeader === true || (opts.hasHeader !== false && !looksNumeric)) {
          continue;
        }
      }
      if (parseLine(line, delimiter, times, open, high, low, close, volume)) rowIndex++;
    }
  };

  // eslint-disable-next-line no-constant-condition
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    handleChunk(decoder.decode(value, { stream: true }));
  }
  handleChunk(decoder.decode());
  if (pending.length > 0) parseLine(pending, delimiter, times, open, high, low, close, volume);

  const volArr = volume.toArray();
  let hasVolume = false;
  for (let i = 0; i < volArr.length; i++) {
    if (volArr[i] !== 0) {
      hasVolume = true;
      break;
    }
  }

  return new CandleSeries({
    symbol: opts.symbol ?? "",
    resolution: opts.resolution ?? "",
    times: times.toArray(),
    open: open.toArray(),
    high: high.toArray(),
    low: low.toArray(),
    close: close.toArray(),
    volume: hasVolume ? volArr : null,
  });
}
