// Shared domain types for the Replay Pro trading simulator.

export interface Bar {
  time: number; // epoch ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type OrderSide = "BUY" | "SELL";
export type OrderKind = "MARKET" | "LIMIT";

export interface PendingOrder {
  id: number;
  type: OrderSide;
  size: number;
  entryPrice: number;
  sl: number;
  tp: number;
  note: string;
  riskAmount: number;
  createdAt: number;
}

export interface Position {
  id: number;
  type: OrderSide;
  size: number;
  entryPrice: number;
  sl: number;
  tp: number;
  note: string;
  riskAmount: number;
  entryTime: string;
}

export interface JournalEntry {
  id: number;
  type: OrderSide;
  size: string;
  entryPrice: string;
  exitPrice: string;
  outcome: "TP" | "SL" | "MANUAL" | "PARTIAL";
  pnl: string;
  balanceAfter: string;
  note: string;
  date: string;
}

export interface Session {
  id: number;
  symbol: string;
  fileName: string;
  initialBalance: number;
  currentBalance: number;
  priceDecimals: number;
  startDate: string;
  endDate: string;
  currentTimestamp: number;
  timeframe: number;
  replayIndex: number;
  tradeJournal: JournalEntry[];
  positions: Position[];
  pendingOrders: PendingOrder[];
  createdAt: number;
}

export interface ChartThemeColors {
  backgroundColor: string;
  gridColor: string;
  candleUpBody: string;
  candleDownBody: string;
  candleUpWick: string;
  candleDownWick: string;
  candleUpBorder: string;
  candleDownBorder: string;
  axisTextColor: string;
}

export interface ChartThemeDef {
  id: string;
  name: string;
  colors: ChartThemeColors;
}

export const DEFAULT_CHART_COLORS: ChartThemeColors = {
  backgroundColor: "#0c0d14",
  gridColor: "#2a2d3a",
  candleUpBody: "#26a69a",
  candleDownBody: "#ef5350",
  candleUpWick: "#26a69a",
  candleDownWick: "#ef5350",
  candleUpBorder: "#26a69a",
  candleDownBorder: "#ef5350",
  axisTextColor: "#787b86",
};