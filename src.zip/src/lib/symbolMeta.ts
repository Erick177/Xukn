// Auto price-decimal detection based on the symbol's name.
// The symbol is read from the folder name (when data is organized in
// per-symbol folders) or from the first "word" of the file name otherwise.

// Table values are the number of digits after the decimal point,
// derived from typical tick sizes for each instrument.
const DECIMALS_BY_SYMBOL: Record<string, number> = {
  // --- explicit values requested ---
  btcusd: 1, // 0.1
  xauusd: 3, // 0.001
  eurusd: 5, // 0.00001

  // --- best-effort additions for other common instruments ---
  btc: 1,
  xau: 3,
  gold: 3,
  eur: 5,

  ethusd: 2, // 0.01
  eth: 2,
  ltcusd: 2,
  xrpusd: 5,

  xagusd: 3, // silver, 0.001
  xag: 3,
  silver: 3,

  gbpusd: 5,
  audusd: 5,
  nzdusd: 5,
  usdcad: 5,
  usdchf: 5,
  eurgbp: 5,
  eurjpy: 3,
  gbpjpy: 3,
  audjpy: 3,
  chfjpy: 3,
  cadjpy: 3,
  nzdjpy: 3,

  usdjpy: 3, // JPY pairs quote to 3 decimals (2 + pip)
  jpy: 3,

  us30: 1,
  nas100: 1,
  spx500: 2,
  ger40: 2,
  uk100: 2,
};

const DEFAULT_DECIMALS = 5;

/** Normalizes an identifier for lookup: lowercase, letters/digits only. */
function normalize(raw: string): string {
  return raw.toLowerCase().replace(/[^a-z0-9]/g, "");
}

/**
 * Extracts the "symbol" token to use for decimal detection out of a
 * (possibly nested) relative file path, e.g.:
 *   "btcusd/btcusd 1h.csv"      -> "btcusd" (top-level folder)
 *   "EURUSD_2020.tsv"           -> "eurusd" (first word of the file name)
 */
export function extractSymbolToken(relativePath: string): string {
  const segments = relativePath.split("/").filter(Boolean);
  if (segments.length > 1) {
    // Organized in a per-symbol folder -> use the top-level folder name.
    return normalize(segments[0]);
  }
  const fileName = segments[0] || relativePath;
  const base = fileName.replace(/\.[^./]+$/, ""); // strip extension
  const firstWord = base.split(/[\s_-]+/)[0] || base;
  return normalize(firstWord);
}

/**
 * Returns the number of price decimals to use for a given data file path.
 * Falls back to DEFAULT_DECIMALS (5) when the symbol isn't recognized.
 */
export function detectPriceDecimals(relativePath: string): number {
  const token = extractSymbolToken(relativePath);
  if (token in DECIMALS_BY_SYMBOL) return DECIMALS_BY_SYMBOL[token];

  // Try to match a known symbol as a prefix (e.g. "btcusdt" -> "btc").
  for (const key of Object.keys(DECIMALS_BY_SYMBOL)) {
    if (token.startsWith(key)) return DECIMALS_BY_SYMBOL[key];
  }

  return DEFAULT_DECIMALS;
}
