// src/lib/sessionActions.ts
"use server";

import fs from "fs";
import path from "path";
import type { Session } from "@/lib/types";

const SESSIONS_DIR = path.join(process.cwd(), "sessions");

if (!fs.existsSync(SESSIONS_DIR)) {
  fs.mkdirSync(SESSIONS_DIR, { recursive: true });
}

export async function saveSessionsToServer(sessions: Session[]): Promise<void> {
  try {
    const files = fs.readdirSync(SESSIONS_DIR);
    for (const file of files) {
      if (file.endsWith(".json")) {
        fs.unlinkSync(path.join(SESSIONS_DIR, file));
      }
    }
    
    for (const session of sessions) {
      const filePath = path.join(SESSIONS_DIR, `session-${session.id}.json`);
      fs.writeFileSync(filePath, JSON.stringify(session, null, 2));
    }
  } catch (error) {
    console.error("Failed to save sessions:", error);
    throw new Error("Failed to save sessions");
  }
}

export async function loadSessionsFromServer(): Promise<Session[]> {
  try {
    const files = fs.readdirSync(SESSIONS_DIR);
    const sessions: Session[] = [];
    
    for (const file of files) {
      if (file.endsWith(".json")) {
        const content = fs.readFileSync(path.join(SESSIONS_DIR, file), "utf8");
        const session = JSON.parse(content);
        sessions.push(session);
      }
    }
    
    return sessions.sort((a, b) => a.createdAt - b.createdAt);
  } catch (error) {
    console.error("Failed to load sessions:", error);
    return [];
  }
}

export async function deleteSessionFromServer(id: number): Promise<void> {
  try {
    const filePath = path.join(SESSIONS_DIR, `session-${id}.json`);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (error) {
    console.error(`Failed to delete session ${id}:`, error);
  }
}