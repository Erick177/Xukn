// src/lib/xbin/gzip.ts

import { gzipSync, gunzipSync } from "fflate";

const hasNativeCompressionStream =
  typeof CompressionStream !== "undefined" && typeof Response !== "undefined";
const hasNativeDecompressionStream =
  typeof DecompressionStream !== "undefined" && typeof Response !== "undefined";

function toArrayBuffer(data: Uint8Array): ArrayBuffer {
  if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength && data.buffer instanceof ArrayBuffer) {
    return data.buffer;
  }
  return data.slice().buffer as ArrayBuffer;
}

export async function gzipCompress(data: Uint8Array, level = 9): Promise<Uint8Array> {
  if (hasNativeCompressionStream) {
    try {
      const stream = new Blob([toArrayBuffer(data)]).stream().pipeThrough(new CompressionStream("gzip"));
      const buf = await new Response(stream).arrayBuffer();
      return new Uint8Array(buf);
    } catch {
      // fall through to fflate
    }
  }
  return gzipSync(data, { level: level as 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 });
}

export async function gzipDecompress(data: Uint8Array): Promise<Uint8Array> {
  if (hasNativeDecompressionStream) {
    try {
      const stream = new Blob([toArrayBuffer(data)]).stream().pipeThrough(new DecompressionStream("gzip"));
      const buf = await new Response(stream).arrayBuffer();
      return new Uint8Array(buf);
    } catch {
      // fall through to fflate
    }
  }
  return gunzipSync(data);
}

export function gzipDecompressSync(data: Uint8Array): Uint8Array {
  return gunzipSync(data);
}

export function gzipCompressSync(data: Uint8Array, level = 9): Uint8Array {
  return gzipSync(data, { level: level as 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 });
}