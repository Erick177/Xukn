// src/lib/xbin/constants.ts

export const XBIN_MAGIC = 0x584e4231;
export const XBIN_MAGIC_BYTES = [0x58, 0x42, 0x4e, 0x31];
export const XBIN_VERSION = 1;
export const DEFAULT_PRICE_SCALE = 100000;
export const FLAG_HAS_VOLUME = 1 << 0;

export interface Bar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface XbinEncodeOptions {
  symbol?: string;
  resolution?: string;
  priceScale?: number;
  hasVolume?: boolean;
  level?: number;
}

export interface DecodedSeries {
  symbol: string;
  resolution: string;
  count: number;
  priceScale: number;
  times: Float64Array;
  open: Float32Array;
  high: Float32Array;
  low: Float32Array;
  close: Float32Array;
  volume: Float32Array | null;
}

export interface XbinHeader {
  magic: string;
  version: number;
  flags: number;
  reserved: number;
  priceScale: number;
  count: number;
  baseTime: number;
  timeStep: number;
  symbol: string;
  resolution: string;
}

export function readHeader(buffer: Buffer | Uint8Array): XbinHeader | null {
  if (buffer.length < 32) return null;

  const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.length);
  let offset = 0;

  const magic = new TextDecoder().decode(buffer.slice(0, 4));
  if (magic !== "XBN1") return null;
  offset += 4;

  const version = view.getUint8(offset);
  offset += 1;
  if (version !== XBIN_VERSION) return null;

  const flags = view.getUint8(offset);
  offset += 1;
  const reserved = view.getUint16(offset, true);
  offset += 2;

  const priceScale = view.getUint32(offset, true);
  offset += 4;
  const count = view.getUint32(offset, true);
  offset += 4;

  const baseTime = view.getFloat64(offset, true);
  offset += 8;
  const timeStep = view.getInt32(offset, true);
  offset += 4;

  const symbolLen = view.getUint16(offset, true);
  offset += 2;
  const symbol = new TextDecoder().decode(buffer.slice(offset, offset + symbolLen));
  offset += symbolLen;

  const resolutionLen = view.getUint16(offset, true);
  offset += 2;
  const resolution = new TextDecoder().decode(buffer.slice(offset, offset + resolutionLen));

  return {
    magic,
    version,
    flags,
    reserved,
    priceScale,
    count,
    baseTime,
    timeStep,
    symbol,
    resolution,
  };
}