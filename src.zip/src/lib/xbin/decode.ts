// src/lib/xbin/decode.ts

import { DecodedSeries, XBIN_MAGIC_BYTES } from "./constants";
import { gzipDecompress, gzipDecompressSync } from "./gzip";

function readHeader(view: DataView, bytes: Uint8Array) {
  for (let i = 0; i < 4; i++) {
    if (bytes[i] !== XBIN_MAGIC_BYTES[i]) {
      throw new Error("Invalid XBIN file: bad magic header");
    }
  }
  let o = 4;
  const version = view.getUint8(o);
  o += 1;
  const flags = view.getUint8(o);
  o += 1;
  o += 2;
  const priceScale = view.getUint32(o, true);
  o += 4;
  const count = view.getUint32(o, true);
  o += 4;
  const baseTime = view.getFloat64(o, true);
  o += 8;
  const timeStep = view.getInt32(o, true);
  o += 4;
  const symbolLen = view.getUint16(o, true);
  o += 2;
  const symbol = new TextDecoder().decode(bytes.subarray(o, o + symbolLen));
  o += symbolLen;
  const resolutionLen = view.getUint16(o, true);
  o += 2;
  const resolution = new TextDecoder().decode(bytes.subarray(o, o + resolutionLen));
  o += resolutionLen;
  const dataStart = (o + 3) & ~3;

  return { version, flags, priceScale, count, baseTime, timeStep, symbol, resolution, dataStart };
}

export function decodeXbinPayload(buffer: ArrayBuffer | Uint8Array): DecodedSeries {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const h = readHeader(view, bytes);
  const hasVolume = (h.flags & 1) === 1;
  const count = h.count;

  const times = new Float64Array(count);
  const open = new Float32Array(count);
  const high = new Float32Array(count);
  const low = new Float32Array(count);
  const close = new Float32Array(count);
  const volume = hasVolume ? new Float32Array(count) : null;

  let o = h.dataStart;

  if (h.timeStep !== 0) {
    for (let i = 0; i < count; i++) times[i] = h.baseTime + i * h.timeStep;
  } else {
    times[0] = h.baseTime;
    for (let i = 1; i < count; i++) {
      times[i] = times[i - 1] + view.getInt32(o, true);
      o += 4;
    }
  }

  const invScale = 1 / h.priceScale;
  const openScaled = new Int32Array(count);
  let acc = 0;
  for (let i = 0; i < count; i++) {
    const delta = view.getInt32(o, true);
    o += 4;
    acc = i === 0 ? delta : acc + delta;
    openScaled[i] = acc;
    open[i] = acc * invScale;
  }
  for (let i = 0; i < count; i++) {
    const rel = view.getInt32(o, true);
    o += 4;
    high[i] = (openScaled[i] + rel) * invScale;
  }
  for (let i = 0; i < count; i++) {
    const rel = view.getInt32(o, true);
    o += 4;
    low[i] = (openScaled[i] - rel) * invScale;
  }
  for (let i = 0; i < count; i++) {
    const rel = view.getInt32(o, true);
    o += 4;
    close[i] = (openScaled[i] + rel) * invScale;
  }
  if (hasVolume && volume) {
    for (let i = 0; i < count; i++) {
      volume[i] = view.getFloat32(o, true);
      o += 4;
    }
  }

  return {
    symbol: h.symbol,
    resolution: h.resolution,
    count,
    priceScale: h.priceScale,
    times,
    open,
    high,
    low,
    close,
    volume,
  };
}

export async function decodeXbin(compressed: ArrayBuffer | Uint8Array): Promise<DecodedSeries> {
  const bytes = compressed instanceof Uint8Array ? compressed : new Uint8Array(compressed);
  const payload = await gzipDecompress(bytes);
  return decodeXbinPayload(payload);
}

export function decodeXbinSync(compressed: ArrayBuffer | Uint8Array): DecodedSeries {
  const bytes = compressed instanceof Uint8Array ? compressed : new Uint8Array(compressed);
  const payload = gzipDecompressSync(bytes);
  return decodeXbinPayload(payload);
}