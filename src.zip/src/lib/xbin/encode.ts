// src/lib/xbin/encode.ts

import { Bar, DEFAULT_PRICE_SCALE, FLAG_HAS_VOLUME, XBIN_MAGIC_BYTES, XBIN_VERSION, XbinEncodeOptions } from "./constants";
import { gzipCompress } from "./gzip";

function utf8(str: string): Uint8Array {
  return new TextEncoder().encode(str);
}

function align4(n: number): number {
  return (n + 3) & ~3;
}

export function encodeXbinPayload(bars: Bar[], opts: XbinEncodeOptions = {}): Uint8Array {
  const count = bars.length;
  const priceScale = opts.priceScale ?? DEFAULT_PRICE_SCALE;
  const hasVolume = opts.hasVolume ?? bars.some((b) => typeof b.volume === "number" && b.volume > 0);
  const symbolBytes = utf8(opts.symbol ?? "");
  const resolutionBytes = utf8(opts.resolution ?? "");

  let timeStep = 0;
  if (count > 1) {
    const step = bars[1].time - bars[0].time;
    let regular = step > 0;
    for (let i = 2; i < count && regular; i++) {
      if (bars[i].time - bars[i - 1].time !== step) regular = false;
    }
    if (regular) timeStep = step;
  }

  const headerFixedSize = 4 + 1 + 1 + 2 + 4 + 4 + 8 + 4 + 2 + 2;
  const headerSize = headerFixedSize + symbolBytes.length + resolutionBytes.length;
  const dataStart = align4(headerSize);

  const timeArrLen = timeStep === 0 && count > 0 ? count - 1 : 0;
  const dataSize =
    timeArrLen * 4 +
    count * 4 +
    count * 4 +
    count * 4 +
    count * 4 +
    (hasVolume ? count * 4 : 0);

  const total = dataStart + dataSize;
  const buf = new ArrayBuffer(total);
  const view = new DataView(buf);
  const bytes = new Uint8Array(buf);

  let o = 0;
  bytes.set(XBIN_MAGIC_BYTES, o);
  o += 4;
  view.setUint8(o, XBIN_VERSION);
  o += 1;
  view.setUint8(o, hasVolume ? FLAG_HAS_VOLUME : 0);
  o += 1;
  view.setUint16(o, 0, true);
  o += 2;
  view.setUint32(o, priceScale, true);
  o += 4;
  view.setUint32(o, count, true);
  o += 4;
  view.setFloat64(o, count > 0 ? bars[0].time : 0, true);
  o += 8;
  view.setInt32(o, timeStep, true);
  o += 4;
  view.setUint16(o, symbolBytes.length, true);
  o += 2;
  bytes.set(symbolBytes, o);
  o += symbolBytes.length;
  view.setUint16(o, resolutionBytes.length, true);
  o += 2;
  bytes.set(resolutionBytes, o);
  o += resolutionBytes.length;

  o = dataStart;

  if (timeArrLen > 0) {
    for (let i = 1; i < count; i++) {
      view.setInt32(o, bars[i].time - bars[i - 1].time, true);
      o += 4;
    }
  }

  let prevOpenScaled = 0;
  for (let i = 0; i < count; i++) {
    const openScaled = Math.round(bars[i].open * priceScale);
    const delta = i === 0 ? openScaled : openScaled - prevOpenScaled;
    view.setInt32(o, delta, true);
    o += 4;
    prevOpenScaled = openScaled;
  }
  prevOpenScaled = 0;
  for (let i = 0; i < count; i++) {
    const openScaled = Math.round(bars[i].open * priceScale);
    const highScaled = Math.round(bars[i].high * priceScale);
    view.setInt32(o, highScaled - openScaled, true);
    o += 4;
  }
  for (let i = 0; i < count; i++) {
    const openScaled = Math.round(bars[i].open * priceScale);
    const lowScaled = Math.round(bars[i].low * priceScale);
    view.setInt32(o, openScaled - lowScaled, true);
    o += 4;
  }
  for (let i = 0; i < count; i++) {
    const openScaled = Math.round(bars[i].open * priceScale);
    const closeScaled = Math.round(bars[i].close * priceScale);
    view.setInt32(o, closeScaled - openScaled, true);
    o += 4;
  }
  if (hasVolume) {
    for (let i = 0; i < count; i++) {
      view.setFloat32(o, bars[i].volume ?? 0, true);
      o += 4;
    }
  }

  return bytes;
}

export async function encodeXbin(bars: Bar[], opts: XbinEncodeOptions = {}): Promise<Uint8Array> {
  const payload = encodeXbinPayload(bars, opts);
  return gzipCompress(payload, opts.level ?? 9);
}