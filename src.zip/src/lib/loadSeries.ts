// src/lib/loadSeries.ts

import { CandleSeries } from "./candleSeries";

export type SeriesFormat = "csv" | "xbin";

export interface LoadSeriesOptions {
  format?: SeriesFormat;
  symbol?: string;
  resolution?: string;
  useWorker?: boolean;
}

export async function loadSeries(
  url: string,
  options: LoadSeriesOptions = {}
): Promise<CandleSeries> {
  const format = options.format ?? (url.endsWith(".xbin") ? "xbin" : "csv");

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to load ${url}: ${response.status}`);
  }

  if (format === "xbin") {
    const buffer = await response.arrayBuffer();
    const { decodeXbin } = await import("@/lib/xbin/decode");
    return decodeXbin(new Uint8Array(buffer));
  }

  const text = await response.text();
  const { parseCsv } = await import("@/lib/csvLoader");
  return parseCsv(text);
}