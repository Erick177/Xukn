// src/lib/streamCsv.ts
import fs from "fs";
import readline from "readline";
import { Bar } from "./types";
import { parseCsvLine, parseTabLine, pickVolumeColumn } from "./csv";

interface ReadBarsOptions {
  from?: number;
  to?: number;
  countBack?: number;
}

function detectFileFormat(firstLine: string): "csv" | "tab" {
  if (firstLine.includes("\t")) return "tab";
  return "csv";
}

function isHeaderLine(line: string, format: "csv" | "tab"): boolean {
  const trimmed = line.trim().toLowerCase();
  if (format === "csv") {
    return trimmed.startsWith("date") || 
           trimmed.startsWith("time") || 
           trimmed.startsWith("datetime") ||
           (trimmed.includes("open") && trimmed.includes("close"));
  } else {
    const parts = line.split("\t").map(p => p.trim().toLowerCase());
    return parts.some(p => p === "time" || p === "date" || p === "datetime") &&
           parts.some(p => p === "open" || p === "high" || p === "low" || p === "close");
  }
}

async function findStartOffset(
  fd: fs.promises.FileHandle,
  fileSize: number,
  from: number,
  parser: (line: string) => Bar | null,
  format: "csv" | "tab"
): Promise<number> {
  let low = 0;
  let high = fileSize;
  let bestOffset = 0;
  let found = false;
  const bufferSize = 4096;

  while (low <= high) {
    const mid = Math.floor((low + high) / 2);
    const buffer = Buffer.alloc(bufferSize);
    const { bytesRead } = await fd.read(buffer, 0, bufferSize, mid);
    
    if (bytesRead === 0) {
      high = mid - 1;
      continue;
    }

    const text = buffer.toString("utf8");
    const newlineIdx = text.indexOf("\n");
    
    if (newlineIdx === -1 || mid + newlineIdx + 1 >= fileSize) {
      high = mid - 1;
      continue;
    }

    const lineStartOffset = mid + newlineIdx + 1;
    const lineBuffer = Buffer.alloc(1024);
    const { bytesRead: lineBytes } = await fd.read(lineBuffer, 0, 1024, lineStartOffset);
    
    if (lineBytes === 0) {
      high = mid - 1;
      continue;
    }

    const lineText = lineBuffer.toString("utf8");
    const lineEndIdx = lineText.indexOf("\n");
    const line = (lineEndIdx !== -1 ? lineText.slice(0, lineEndIdx) : lineText).trim();

    if (isHeaderLine(line, format)) {
      low = mid + 1;
      continue;
    }

    const bar = parser(line);
    if (bar && !isNaN(bar.time)) {
      if (bar.time >= from) {
        bestOffset = lineStartOffset;
        found = true;
        high = mid - 1;
      } else {
        low = mid + 1;
      }
    } else {
      low = mid + 1;
    }
  }

  return found ? bestOffset : 0;
}

async function findOffsetBefore(
  fd: fs.promises.FileHandle,
  startOffset: number,
  count: number,
  parser: (line: string) => Bar | null,
  format: "csv" | "tab"
): Promise<number> {
  let offset = startOffset;
  let found = 0;
  let bufferSize = 4096;
  let currentOffset = startOffset;
  
  while (found < count && currentOffset > 0) {
    const readSize = Math.min(bufferSize, currentOffset);
    const buffer = Buffer.alloc(readSize);
    const { bytesRead } = await fd.read(buffer, 0, readSize, currentOffset - readSize);
    
    if (bytesRead === 0) break;
    
    const text = buffer.toString("utf8", 0, bytesRead);
    const lines = text.split("\n").filter(l => l.trim().length > 0);
    
    for (let i = lines.length - 1; i >= 0; i--) {
      const line = lines[i];
      if (isHeaderLine(line, format)) continue;
      const bar = parser(line);
      if (bar) {
        found++;
        if (found === count) {
          const lineInBuffer = text.lastIndexOf(line);
          const offsetInBuffer = currentOffset - readSize + lineInBuffer;
          return offsetInBuffer;
        }
      }
    }
    
    currentOffset -= readSize;
  }
  
  return startOffset;
}

export async function readBarsStream(
  filePath: string,
  options: ReadBarsOptions = {}
): Promise<Bar[]> {
  const { from, to, countBack } = options;
  
  const stats = await fs.promises.stat(filePath);
  const fileSize = stats.size;
  if (fileSize === 0) return [];

  const headBuffer = Buffer.alloc(4096);
  const fd = await fs.promises.open(filePath, "r");
  await fd.read(headBuffer, 0, 4096, 0);
  await fd.close();

  const headText = headBuffer.toString("utf8");
  const lines = headText.split("\n").filter(l => l.trim().length > 0);
  const firstLine = lines.length > 0 ? lines[0] : "";
  
  const format = detectFileFormat(firstLine);
  const isTab = format === "tab";
  
  let volumeColumnIndex = 5;
  let parser: (line: string) => Bar | null;
  
  if (isTab) {
    const sampleLines: string[] = [];
    const sampleFd = await fs.promises.open(filePath, "r");
    const sampleBuffer = Buffer.alloc(32768);
    const { bytesRead: sampleBytes } = await sampleFd.read(sampleBuffer, 0, 32768, 0);
    await sampleFd.close();
    
    const sampleText = sampleBuffer.toString("utf8", 0, sampleBytes);
    const sampleLinesArray = sampleText.split("\n")
      .filter(l => l.trim().length > 0)
      .filter(l => !isHeaderLine(l, "tab"));
    
    if (sampleLinesArray.length > 0) {
      volumeColumnIndex = pickVolumeColumn(sampleLinesArray);
    }
    
    parser = (line: string) => parseTabLine(line, volumeColumnIndex);
  } else {
    parser = parseCsvLine;
  }

  let startOffset = 0;
  if (from !== undefined && fileSize > 0) {
    const searchFd = await fs.promises.open(filePath, "r");
    try {
      startOffset = await findStartOffset(searchFd, fileSize, from, parser, format);
      
      const extraCount = countBack || 5000;
      const extraOffset = await findOffsetBefore(searchFd, startOffset, extraCount, parser, format);
      startOffset = extraOffset;
    } finally {
      await searchFd.close();
    }
  }

  return new Promise((resolve, reject) => {
    const fileStream = fs.createReadStream(filePath, { 
      start: startOffset,
      encoding: "utf8"
    });
    
    const rl = readline.createInterface({
      input: fileStream,
      crlfDelay: Infinity,
    });

    const bars: Bar[] = [];
    let isFirstLine = true;

    rl.on("line", (line) => {
      const trimmed = line.trim();
      if (!trimmed) return;

      if (isFirstLine && isHeaderLine(trimmed, format)) {
        isFirstLine = false;
        return;
      }
      isFirstLine = false;

      const bar = parser(trimmed);
      if (!bar) return;

      if (from !== undefined && bar.time < from) return;
      if (to !== undefined && bar.time > to) return;

      bars.push(bar);
    });

    rl.on("close", () => {
      if (countBack !== undefined && bars.length > countBack) {
        resolve(bars.slice(bars.length - countBack));
      } else {
        resolve(bars);
      }
    });

    rl.on("error", (err) => reject(err));
    fileStream.on("error", (err) => reject(err));
  });
}

export async function readFirstLastTimestamps(filePath: string): Promise<{ start: number; end: number } | null> {
  const stats = await fs.promises.stat(filePath);
  const fileSize = stats.size;
  if (fileSize === 0) return null;

  const headBuffer = Buffer.alloc(4096);
  const fd = await fs.promises.open(filePath, "r");
  await fd.read(headBuffer, 0, 4096, 0);
  await fd.close();

  const headText = headBuffer.toString("utf8");
  const lines = headText.split("\n").filter(l => l.trim().length > 0);
  const firstLine = lines.length > 0 ? lines[0] : "";
  
  const format = detectFileFormat(firstLine);
  const isTab = format === "tab";
  const parser = isTab ? parseTabLine : parseCsvLine;

  let firstBar: Bar | null = null;
  const firstFd = await fs.promises.open(filePath, "r");
  try {
    const buffer = Buffer.alloc(4096);
    const { bytesRead } = await firstFd.read(buffer, 0, 4096, 0);
    const text = buffer.toString("utf8", 0, bytesRead);
    const firstLines = text.split("\n").filter(l => l.trim().length > 0);
    
    let found = false;
    for (const line of firstLines) {
      if (isHeaderLine(line, format)) continue;
      const bar = parser(line);
      if (bar) {
        firstBar = bar;
        found = true;
        break;
      }
    }
    
    if (!found) {
      const rl = readline.createInterface({
        input: fs.createReadStream(filePath, { encoding: "utf8" }),
        crlfDelay: Infinity,
      });
      
      await new Promise<void>((resolve) => {
        rl.on("line", (line) => {
          if (firstBar) return;
          if (isHeaderLine(line, format)) return;
          const bar = parser(line);
          if (bar) {
            firstBar = bar;
            rl.close();
            resolve();
          }
        });
        rl.on("close", () => resolve());
      });
    }
  } finally {
    await firstFd.close();
  }

  if (!firstBar) return null;

  let lastBar: Bar | null = null;
  const tailSize = Math.min(fileSize, 32768);
  const tailFd = await fs.promises.open(filePath, "r");
  try {
    const buffer = Buffer.alloc(tailSize);
    const { bytesRead } = await tailFd.read(buffer, 0, tailSize, fileSize - tailSize);
    const text = buffer.toString("utf8", 0, bytesRead);
    const tailLines = text.split("\n").filter(l => l.trim().length > 0);
    
    for (let i = tailLines.length - 1; i >= 0; i--) {
      const line = tailLines[i];
      if (isHeaderLine(line, format)) continue;
      const bar = parser(line);
      if (bar) {
        lastBar = bar;
        break;
      }
    }
    
    if (!lastBar) {
      const rl = readline.createInterface({
        input: fs.createReadStream(filePath, { 
          encoding: "utf8",
          start: Math.max(0, fileSize - 65536)
        }),
        crlfDelay: Infinity,
      });
      
      const allLines: string[] = [];
      await new Promise<void>((resolve) => {
        rl.on("line", (line) => allLines.push(line));
        rl.on("close", () => resolve());
      });
      
      for (let i = allLines.length - 1; i >= 0; i--) {
        const line = allLines[i];
        if (isHeaderLine(line, format)) continue;
        const bar = parser(line);
        if (bar) {
          lastBar = bar;
          break;
        }
      }
    }
  } finally {
    await tailFd.close();
  }

  if (!lastBar) return null;

  return { start: firstBar.time, end: lastBar.time };
}