"use client";

import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";
import Icon from "@/components/Icon";

export default function TradePanel() {
  const open = useReplayStore((s) => s.tradePanelOpen);
  const pushToast = useReplayStore((s) => s.pushToast);

  const orderKind = useReplayStore((s) => s.orderKind);
  const orderEntryPrice = useReplayStore((s) => s.orderEntryPrice);
  const orderSl = useReplayStore((s) => s.orderSl);
  const orderRr = useReplayStore((s) => s.orderRr);
  const orderRiskUsd = useReplayStore((s) => s.orderRiskUsd);
  const orderNote = useReplayStore((s) => s.orderNote);
  const setOrderKind = useReplayStore((s) => s.setOrderKind);
  const setOrderEntryPrice = useReplayStore((s) => s.setOrderEntryPrice);
  const setOrderSl = useReplayStore((s) => s.setOrderSl);
  const setOrderRr = useReplayStore((s) => s.setOrderRr);
  const setOrderRiskUsd = useReplayStore((s) => s.setOrderRiskUsd);
  const setOrderNote = useReplayStore((s) => s.setOrderNote);

  if (!open) return null;

  function submit(type: "BUY" | "SELL") {
    replayEngine.createOrder({
      type,
      kind: orderKind,
      entryPrice: orderKind === "LIMIT" ? parseFloat(orderEntryPrice) : undefined,
      sl: parseFloat(orderSl),
      rr: parseFloat(orderRr) || 2,
      riskUsd: parseFloat(orderRiskUsd) || 10,
      note: orderNote,
    });
    setOrderNote("");
  }

  function importFromDrawing() {
    const result = replayEngine.importFromDrawing();
    if (!result) {
      pushToast("No RR Long/Short tool selected on chart", "warning");
      return;
    }
    const isLimitOrStop = result.executionType !== "market";
    setOrderKind(isLimitOrStop ? "LIMIT" : "MARKET");
    if (isLimitOrStop) setOrderEntryPrice(String(result.entryPrice));
    setOrderSl(String(result.stopLoss));
    const distance = Math.abs(result.entryPrice - result.stopLoss);
    const reward = Math.abs(result.takeProfit - result.entryPrice);
    if (distance > 0) setOrderRr((reward / distance).toFixed(2));
    pushToast(`${result.tradeType} setup loaded (${result.executionType.toUpperCase()})`, "success");
  }

  return (
    <div id="trade-panel-container" className="open">
      <button type="button" className="btn" onClick={importFromDrawing} style={{ width: "100%", justifyContent: "center" }}>
        <Icon name="crosshair" /> Import from RR Drawing
      </button>

      <div className="panel-row">
        <span style={{ color: "var(--text-muted)" }}>Type</span>
        <select
          className="control-input"
          style={{ width: "62%" }}
          value={orderKind}
          onChange={(e) => setOrderKind(e.target.value as "MARKET" | "LIMIT")}
        >
          <option value="MARKET">Market</option>
          <option value="LIMIT">Limit Order</option>
        </select>
      </div>

      {orderKind === "LIMIT" && (
        <div className="panel-row" id="limit-price-row" style={{ display: "flex" }}>
          <span style={{ color: "var(--text-muted)" }}>Limit $</span>
          <input
            type="number"
            className="control-input"
            style={{ width: "62%" }}
            step="0.01"
            value={orderEntryPrice}
            onChange={(e) => setOrderEntryPrice(e.target.value)}
          />
        </div>
      )}

      <div className="panel-row">
        <span style={{ color: "var(--text-muted)" }}>Stop Loss</span>
        <div style={{ display: "flex", gap: 4, width: "62%" }}>
          <input
            type="number"
            className="control-input"
            step="any"
            placeholder="0.0000"
            style={{ flex: 1, width: "100%" }}
            value={orderSl}
            onChange={(e) => setOrderSl(e.target.value)}
          />
        </div>
      </div>

      <div className="panel-row">
        <span style={{ color: "var(--text-muted)" }}>R : R</span>
        <input
          type="number"
          className="control-input"
          style={{ width: "62%" }}
          step="0.1"
          value={orderRr}
          onChange={(e) => setOrderRr(e.target.value)}
        />
      </div>

      <div className="panel-row">
        <span style={{ color: "var(--text-muted)" }}>Risk $</span>
        <input
          type="number"
          className="control-input"
          style={{ width: "62%" }}
          value={orderRiskUsd}
          onChange={(e) => setOrderRiskUsd(e.target.value)}
        />
      </div>

      <input
        type="text"
        className="control-input"
        placeholder="Trade note (optional)…"
        style={{ width: "100%" }}
        value={orderNote}
        onChange={(e) => setOrderNote(e.target.value)}
      />

      <div style={{ display: "flex", gap: 4 }}>
        <button className="btn btn-green" style={{ flex: 1 }} onClick={() => submit("BUY")}>
          <Icon name="trending-up" /> Buy
        </button>
        <button className="btn btn-red" style={{ flex: 1 }} onClick={() => submit("SELL")}>
          <Icon name="trending-down" /> Sell
        </button>
      </div>
    </div>
  );
}
