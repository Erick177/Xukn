import { useState } from "react";

export default function CodeBlock({ code, lang = "ts" }: { code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // ignore
    }
  };

  return (
    <div dir="ltr" className="group relative overflow-hidden rounded-xl border border-slate-800 bg-slate-950 text-left">
      <div className="flex items-center justify-between border-b border-slate-800 px-4 py-2">
        <span className="text-xs font-medium uppercase tracking-wide text-slate-400">{lang}</span>
        <button
          onClick={copy}
          className="rounded-md bg-slate-800 px-2 py-1 text-xs text-slate-200 opacity-0 transition hover:bg-slate-700 group-hover:opacity-100"
        >
          {copied ? "کپی شد ✓" : "کپی"}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 text-[13px] leading-relaxed text-emerald-100">
        <code>{code}</code>
      </pre>
    </div>
  );
}
