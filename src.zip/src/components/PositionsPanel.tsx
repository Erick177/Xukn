"use client";

import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";

export default function PositionsPanel() {
  const positions = useReplayStore((s) => s.positions);
  const pendingOrders = useReplayStore((s) => s.pendingOrders);
  const currentPrice = useReplayStore((s) => s.currentPrice);
  const priceDecimals = useReplayStore((s) => s.priceDecimals);
  const setPositionDetailId = useReplayStore((s) => s.setPositionDetailId);

  return (
    <>
      <div id="active-positions-list">
        {positions.map((pos) => {
          const price = currentPrice ?? pos.entryPrice;
          const pnl = (pos.type === "BUY" ? price - pos.entryPrice : pos.entryPrice - price) * pos.size;
          const color = pnl >= 0 ? "var(--accent-green)" : "var(--accent-red)";
          return (
            <div
              key={pos.id}
              className={`position-card ${pos.type === "BUY" ? "pos-buy" : "pos-sell"}`}
              style={{ cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center" }}
              onClick={() => setPositionDetailId(pos.id)}
            >
              <span style={{ fontWeight: 600, fontSize: 11 }}>
                {pos.type}{" "}
                <span style={{ color: "var(--text-muted)", fontSize: 10 }}>{pos.size.toFixed(4)} units</span>
              </span>
              <span style={{ fontWeight: 700, fontSize: 12, color }}>${pnl.toFixed(2)}</span>
              <span style={{ color: "var(--text-muted)", fontSize: 14, lineHeight: 1 }}>⚙</span>
            </div>
          );
        })}
      </div>

      {pendingOrders.length > 0 && (
        <div id="pending-orders-container" style={{ display: "block" }}>
          {pendingOrders.map((order) => (
            <div
              key={order.id}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: 6,
                padding: "2px 4px",
                borderBottom: "1px solid #2a2f42",
              }}
            >
              <span style={{ fontFamily: "monospace", fontSize: 11 }}>
                {order.type} @ {order.entryPrice.toFixed(priceDecimals)}
              </span>
              <span
                style={{ cursor: "pointer", color: "var(--accent-red)", fontWeight: 700 }}
                onClick={() => replayEngine.cancelPendingOrder(order.id)}
              >
                ✕
              </span>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
