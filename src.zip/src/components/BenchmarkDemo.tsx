import { useState } from "react";
import { generateSampleBars, barsToCsv } from "../demo/sampleData";
import { encodeXbin } from "../lib/xbin/encode";
import { decodeXbin } from "../lib/xbin/decode";
import { parseCsv } from "../lib/csvLoader";
import { CandleSeries } from "../lib/candleSeries";

interface Result {
  count: number;
  csvBytes: number;
  xbinBytes: number;
  csvParseMs: number;
  xbinDecodeMs: number;
  csvMemBytes: number;
  xbinMemBytes: number;
}

const OPTIONS = [10_000, 50_000, 200_000, 500_000];

export default function BenchmarkDemo() {
  const [count, setCount] = useState(50_000);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const run = async () => {
    setRunning(true);
    setResult(null);
    // allow UI to paint the loading state before the heavy synchronous work starts
    await new Promise((r) => setTimeout(r, 30));

    const bars = generateSampleBars(count);

    const csvText = barsToCsv(bars);
    const csvBytes = new TextEncoder().encode(csvText).byteLength;

    const t0 = performance.now();
    const csvSeries = parseCsv(csvText, { symbol: "DEMO", resolution: "1D" });
    const csvParseMs = performance.now() - t0;

    const xbinBuf = await encodeXbin(bars, { symbol: "DEMO", resolution: "1D" });

    const t1 = performance.now();
    const decoded = await decodeXbin(xbinBuf);
    const xbinDecodeMs = performance.now() - t1;
    const xbinSeries = CandleSeries.fromDecoded(decoded);

    setResult({
      count,
      csvBytes,
      xbinBytes: xbinBuf.byteLength,
      csvParseMs,
      xbinDecodeMs,
      csvMemBytes: csvSeries.byteLength,
      xbinMemBytes: xbinSeries.byteLength,
    });
    setRunning(false);
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-center gap-3">
        <span className="text-sm font-medium text-slate-600">تعداد کندل نمونه:</span>
        {OPTIONS.map((opt) => (
          <button
            key={opt}
            onClick={() => setCount(opt)}
            className={`rounded-full px-3 py-1.5 text-sm font-medium transition ${
              count === opt ? "bg-indigo-600 text-white shadow" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            {opt.toLocaleString("fa-IR")}
          </button>
        ))}
        <button
          onClick={run}
          disabled={running}
          className="mr-auto rounded-full bg-emerald-600 px-5 py-1.5 text-sm font-semibold text-white shadow transition hover:bg-emerald-500 disabled:opacity-60"
        >
          {running ? "در حال اجرا…" : "اجرای بنچمارک"}
        </button>
      </div>

      {result && (
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <StatBlock
            title="حجم فایل (روی شبکه/دیسک)"
            rows={[
              ["CSV", formatBytes(result.csvBytes), "bg-rose-400"],
              ["XBIN (gzip)", formatBytes(result.xbinBytes), "bg-emerald-500"],
            ]}
            footer={`${(100 * (1 - result.xbinBytes / result.csvBytes)).toFixed(1)}٪ کوچک‌تر`}
            maxValue={result.csvBytes}
            values={[result.csvBytes, result.xbinBytes]}
          />
          <StatBlock
            title="زمان پردازش/دیکد (ms)"
            rows={[
              ["CSV parse", result.csvParseMs.toFixed(1) + " ms", "bg-rose-400"],
              ["XBIN decode", result.xbinDecodeMs.toFixed(1) + " ms", "bg-emerald-500"],
            ]}
            footer={`${(result.csvParseMs / Math.max(result.xbinDecodeMs, 0.001)).toFixed(1)}× سریع‌تر`}
            maxValue={result.csvParseMs}
            values={[result.csvParseMs, result.xbinDecodeMs]}
          />
          <StatBlock
            title="حافظه نهایی در RAM (typed arrays)"
            rows={[
              ["از CSV ساخته‌شده", formatBytes(result.csvMemBytes), "bg-rose-400"],
              ["از XBIN ساخته‌شده", formatBytes(result.xbinMemBytes), "bg-emerald-500"],
            ]}
            footer="هر دو ستونی (SoA) هستند؛ تفاوت اصلی XBIN در حجم انتقال و سرعت دیکد است."
            maxValue={Math.max(result.csvMemBytes, result.xbinMemBytes)}
            values={[result.csvMemBytes, result.xbinMemBytes]}
          />
          <div className="rounded-xl bg-indigo-50 p-4 text-sm text-indigo-800">
            <p className="font-semibold">جمع‌بندی</p>
            <p className="mt-1 leading-relaxed">
              برای {result.count.toLocaleString("fa-IR")} کندل، فرمت XBIN حدود{" "}
              <b>{(result.csvBytes / result.xbinBytes).toFixed(1)}×</b> فشرده‌تر از CSV است و دیکد آن{" "}
              <b>{(result.csvParseMs / Math.max(result.xbinDecodeMs, 0.001)).toFixed(1)}×</b> سریع‌تر از پارس متنی
              CSV انجام می‌شود — یعنی دانلود سریع‌تر، مصرف کمتر پهنای‌باند و رندر سریع‌تر چارت.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function StatBlock({
  title,
  rows,
  footer,
  values,
  maxValue,
}: {
  title: string;
  rows: [string, string, string][];
  footer: string;
  values: number[];
  maxValue: number;
}) {
  return (
    <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
      <p className="text-sm font-semibold text-slate-700">{title}</p>
      <div className="mt-3 space-y-2">
        {rows.map(([label, value, color], i) => (
          <div key={label}>
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>{label}</span>
              <span className="font-mono text-slate-700">{value}</span>
            </div>
            <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-200">
              <div
                className={`h-full ${color} rounded-full`}
                style={{ width: `${maxValue > 0 ? (values[i] / maxValue) * 100 : 0}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs font-medium text-slate-500">{footer}</p>
    </div>
  );
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
