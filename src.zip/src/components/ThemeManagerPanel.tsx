"use client";

import { useState } from "react";
import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";
import { saveThemesToBrowser } from "@/lib/themeIO";
import { DEFAULT_CHART_COLORS, type ChartThemeColors, type ChartThemeDef } from "@/lib/types";
import Icon from "@/components/Icon";

function applyColorsToChart(colors: ChartThemeColors) {
  const chart = replayEngine.getWidget()?.activeChart();
  if (!chart) return;
  try {
    chart.applyOverrides({
      "paneProperties.background": colors.backgroundColor,
      "paneProperties.vertGridColor": colors.gridColor,
      "paneProperties.horzGridColor": colors.gridColor,
      "mainSeriesProperties.candleStyle.upColor": colors.candleUpBody,
      "mainSeriesProperties.candleStyle.downColor": colors.candleDownBody,
      "mainSeriesProperties.candleStyle.wickUpColor": colors.candleUpWick,
      "mainSeriesProperties.candleStyle.wickDownColor": colors.candleDownWick,
      "mainSeriesProperties.candleStyle.borderUpColor": colors.candleUpBorder,
      "mainSeriesProperties.candleStyle.borderDownColor": colors.candleDownBorder,
      "scalesProperties.textColor": colors.axisTextColor,
    });
  } catch {
    // widget might not be ready
  }
}

export default function ThemeManagerPanel() {
  const open = useReplayStore((s) => s.themeManagerOpen);
  const toggle = useReplayStore((s) => s.toggleThemeManager);
  const themes = useReplayStore((s) => s.themes);
  const setThemes = useReplayStore((s) => s.setThemes);
  const chartMode = useReplayStore((s) => s.chartMode);
  const setChartMode = useReplayStore((s) => s.setChartMode);
  const pushToast = useReplayStore((s) => s.pushToast);

  const [lastAppliedColors, setLastAppliedColors] = useState<ChartThemeColors>(DEFAULT_CHART_COLORS);

  if (!open) return null;

  function toggleMode() {
    const next = chartMode === "dark" ? "light" : "dark";
    setChartMode(next);
    document.body.classList.toggle("light-theme", next === "light");
    replayEngine.applyChartMode(next);
  }

  function addCurrent() {
    const name = window.prompt("Name for this theme:", "My Theme");
    if (!name || !name.trim()) return;
    const theme: ChartThemeDef = {
      id: `th-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name: name.trim(),
      colors: lastAppliedColors,
    };
    setThemes([...themes, theme]);
    pushToast(`Theme "${theme.name}" added!`, "success");
  }

  function apply(theme: ChartThemeDef) {
    applyColorsToChart(theme.colors);
    setLastAppliedColors(theme.colors);
    pushToast("Theme applied", "success");
  }

  function rename(theme: ChartThemeDef) {
    const name = window.prompt("Rename theme:", theme.name);
    if (!name || !name.trim()) return;
    setThemes(themes.map((t) => (t.id === theme.id ? { ...t, name: name.trim() } : t)));
  }

  function remove(theme: ChartThemeDef) {
    if (!window.confirm("Delete this theme?")) return;
    setThemes(themes.filter((t) => t.id !== theme.id));
  }

  function saveAll() {
    saveThemesToBrowser(themes);
    pushToast("Themes saved in this browser.", "success");
  }

  return (
    <div
      id="ct-wrapper"
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(8,9,14,0.85)",
        backdropFilter: "blur(4px)",
        zIndex: 9998,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) toggle(false);
      }}
    >
      <div
        style={{
          background: "var(--bg-panel)",
          border: "1px solid var(--border-color)",
          borderRadius: 12,
          padding: 18,
          width: 320,
          maxWidth: "95vw",
          boxShadow: "0 16px 48px rgba(0,0,0,.8)",
          display: "flex",
          flexDirection: "column",
          gap: 14,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid var(--border-color)",
            paddingBottom: 10,
          }}
        >
          <span style={{ fontSize: 14, fontWeight: 700, display: "flex", alignItems: "center", gap: 6, color: "#fbbf24" }}>
            <Icon name="palette" size={16} /> Theme Manager
          </span>
          <button
            onClick={() => toggle(false)}
            style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", display: "flex", padding: 4 }}
          >
            <Icon name="x" size={16} />
          </button>
        </div>

        <div
          style={{
            display: "flex",
            gap: 6,
            alignItems: "center",
            justifyContent: "space-between",
            background: "var(--bg-input)",
            padding: "6px 10px",
            borderRadius: 6,
            border: "1px solid var(--border-color)",
          }}
        >
          <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Toggle Theme</span>
          <button
            className="btn"
            onClick={toggleMode}
            style={{ width: 28, height: 28, padding: 0, display: "flex", alignItems: "center", justifyContent: "center" }}
          >
            <Icon name={chartMode === "dark" ? "sun" : "moon"} size={14} />
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 10, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: ".04em" }}>
              Saved Themes
            </span>
            <button
              onClick={addCurrent}
              style={{ background: "var(--accent-blue)", border: "none", color: "#fff", borderRadius: 4, padding: "2px 8px", fontSize: 10, cursor: "pointer", display: "flex", alignItems: "center", gap: 3 }}
            >
              <Icon name="plus" size={10} /> Add Current
            </button>
          </div>

          <div id="ct-list" style={{ display: "flex", flexDirection: "column", gap: 5, maxHeight: 200, overflowY: "auto", paddingRight: 2 }}>
            {themes.length === 0 ? (
              <div style={{ textAlign: "center", padding: 16, color: "var(--text-muted)", fontSize: 11 }}>
                No saved themes yet
              </div>
            ) : (
              themes.map((theme) => (
                <div
                  key={theme.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "6px 8px",
                    background: "var(--bg-input)",
                    borderRadius: 5,
                    border: "1px solid var(--border-color)",
                  }}
                >
                  <span style={{ display: "flex", gap: 2, flexShrink: 0 }}>
                    <span style={{ width: 9, height: 9, borderRadius: 2, background: theme.colors.candleUpBody }} />
                    <span style={{ width: 9, height: 9, borderRadius: 2, background: theme.colors.candleDownBody }} />
                    <span
                      style={{
                        width: 9,
                        height: 9,
                        borderRadius: 2,
                        background: theme.colors.backgroundColor,
                        border: "1px solid var(--border-color)",
                      }}
                    />
                  </span>
                  <span style={{ flex: 1, fontSize: 11, cursor: "pointer" }} onClick={() => apply(theme)} title="Click to apply">
                    {theme.name}
                  </span>
                  <button
                    onClick={() => rename(theme)}
                    title="Rename"
                    style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", display: "flex", padding: "0 2px" }}
                  >
                    <Icon name="pencil" size={11} />
                  </button>
                  <button
                    onClick={() => remove(theme)}
                    title="Delete"
                    style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", display: "flex", padding: "0 2px" }}
                  >
                    <Icon name="trash-2" size={11} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        <button
          onClick={saveAll}
          style={{
            width: "100%",
            background: "var(--accent-green)",
            border: "none",
            color: "#021a17",
            borderRadius: 6,
            padding: 8,
            fontSize: 12,
            fontWeight: 700,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
          }}
        >
          <Icon name="save" size={13} /> Save Themes
        </button>
      </div>
    </div>
  );
}
