"use client";

function Kbd({ children }: { children: string }) {
  return <span className="kbd">{children}</span>;
}

export default function KeyboardHints() {
  return (
    <div id="kb-hints">
      <span>
        <Kbd>Space</Kbd> Play
      </span>
      <span>
        <Kbd>→</Kbd> Step
      </span>
      <span>
        <Kbd>B</Kbd> Buy
      </span>
      <span>
        <Kbd>S</Kbd> Sell
      </span>
      <span>
        <Kbd>D</Kbd> Dashboard
      </span>
      <span>
        <Kbd>J</Kbd> Journal
      </span>
      <span>
        <Kbd>T</Kbd> Theme
      </span>
    </div>
  );
}
