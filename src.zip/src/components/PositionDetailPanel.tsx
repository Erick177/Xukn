"use client";

import { useEffect, useState } from "react";
import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";

const QUICK_PERCENTS = [10, 25, 50, 75, 100];

export default function PositionDetailPanel() {
  const positionDetailId = useReplayStore((s) => s.positionDetailId);
  const setPositionDetailId = useReplayStore((s) => s.setPositionDetailId);
  const positions = useReplayStore((s) => s.positions);
  const currentPrice = useReplayStore((s) => s.currentPrice);
  const priceDecimals = useReplayStore((s) => s.priceDecimals);

  const position = positions.find((p) => p.id === positionDetailId) || null;

  const [sl, setSl] = useState("");
  const [tp, setTp] = useState("");
  const [closeLots, setCloseLots] = useState("");
  const [addLots, setAddLots] = useState("");

  useEffect(() => {
    if (position) {
      setSl(String(position.sl));
      setTp(String(position.tp));
      setCloseLots("");
      setAddLots("");
    }
  }, [position?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!position) return null;

  const price = currentPrice ?? position.entryPrice;
  const pnl = (position.type === "BUY" ? price - position.entryPrice : position.entryPrice - price) * position.size;

  function close() {
    setPositionDetailId(null);
  }

  return (
    <div id="pos-detail-panel" className="active">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontWeight: 700, fontSize: 13, color: "#fff" }}>
          {position!.type} — {position!.size.toFixed(4)} units
        </span>
        <button className="btn btn-icon" onClick={close} style={{ width: 22, height: 22, fontSize: 13 }}>
          ✕
        </button>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <span className="pd-label">Entry</span>
          <span style={{ fontFamily: "monospace" }}>{position!.entryPrice.toFixed(priceDecimals)}</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 2, alignItems: "flex-end" }}>
          <span className="pd-label">PnL</span>
          <span style={{ fontWeight: 700, fontSize: 13, color: pnl >= 0 ? "var(--accent-green)" : "var(--accent-red)" }}>
            ${pnl.toFixed(2)}
          </span>
        </div>
      </div>

      <div className="pd-divider" />

      <div>
        <span className="pd-label" style={{ display: "block", marginBottom: 5 }}>
          Modify SL / TP
        </span>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
            <span className="pd-label">Stop Loss</span>
            <input
              type="number"
              step="any"
              className="control-input"
              style={{ height: 26, fontSize: 11 }}
              value={sl}
              onChange={(e) => setSl(e.target.value)}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
            <span className="pd-label">Take Profit</span>
            <input
              type="number"
              step="any"
              className="control-input"
              style={{ height: 26, fontSize: 11 }}
              value={tp}
              onChange={(e) => setTp(e.target.value)}
            />
          </div>
        </div>
        <button
          className="btn btn-blue"
          style={{ width: "100%", height: 26, fontSize: 11, marginTop: 6 }}
          onClick={() => replayEngine.applyDetailChanges(position!.id, parseFloat(sl), parseFloat(tp))}
        >
          Apply SL / TP
        </button>
      </div>

      <div className="pd-divider" />

      <div>
        <span className="pd-label" style={{ display: "block", marginBottom: 5 }}>
          Close Position
        </span>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <span className="pd-label">Size to close</span>
            <input
              type="number"
              step="0.01"
              min="0.01"
              className="control-input"
              style={{ height: 26, fontSize: 11, width: "100%" }}
              value={closeLots}
              onChange={(e) => setCloseLots(e.target.value)}
            />
          </div>
          <button
            className="btn btn-red"
            style={{ height: 26, fontSize: 11, padding: "0 12px", alignSelf: "flex-end" }}
            onClick={() => {
              const size = parseFloat(closeLots);
              if (!Number.isNaN(size) && size > 0) replayEngine.closePosition(position!.id, size);
            }}
          >
            Close
          </button>
        </div>

        <div style={{ display: "flex", gap: 4, alignItems: "center", flexWrap: "wrap", marginTop: 6 }}>
          {QUICK_PERCENTS.map((pct) => (
            <button
              key={pct}
              className="btn"
              style={{ flex: 1, minWidth: 30, height: 22, fontSize: 9, padding: "0 4px" }}
              onClick={() => replayEngine.closeByPercent(position!.id, pct)}
            >
              {pct}%
            </button>
          ))}
        </div>

        <button
          className="btn"
          style={{ width: "100%", height: 24, fontSize: 10, marginTop: 5, color: "var(--accent-red)", borderColor: "var(--accent-red)" }}
          onClick={() => {
            replayEngine.closePosition(position!.id);
            close();
          }}
        >
          Close All
        </button>
      </div>

      <div className="pd-divider" />

      <div>
        <span className="pd-label" style={{ display: "block", marginBottom: 5 }}>
          Add Volume (Scale-In)
        </span>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <span className="pd-label">Size to add</span>
            <input
              type="number"
              step="0.01"
              min="0.01"
              className="control-input"
              style={{ height: 26, fontSize: 11, width: "100%" }}
              value={addLots}
              onChange={(e) => setAddLots(e.target.value)}
            />
          </div>
          <button
            className="btn btn-green"
            style={{ height: 26, fontSize: 11, padding: "0 12px", alignSelf: "flex-end" }}
            onClick={() => {
              const size = parseFloat(addLots);
              if (!Number.isNaN(size) && size > 0) {
                replayEngine.addVolume(position!.id, size);
                setAddLots("");
              }
            }}
          >
            Add
          </button>
        </div>
      </div>
    </div>
  );
}
