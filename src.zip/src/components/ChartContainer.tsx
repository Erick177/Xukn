"use client";

import { useEffect, useRef } from "react";
import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";
import { useChartingLibrary } from "@/hooks/useChartingLibrary";

export default function ChartContainer() {
  const containerRef = useRef<HTMLDivElement>(null);
  const libraryMissing = useReplayStore((s) => s.libraryMissing);
  const activeSessionId = useReplayStore((s) => s.activeSessionId);

  useChartingLibrary();

  useEffect(() => {
    replayEngine.attachContainer(containerRef.current);
    return () => replayEngine.attachContainer(null);
  }, []);

  return (
    <div id="tv_chart_container" ref={containerRef} style={{ background: "var(--bg-main)" }}>
      {libraryMissing && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            color: "var(--text-muted)",
            textAlign: "center",
            padding: 24,
          }}
        >
          <div style={{ fontSize: 15, fontWeight: 700, color: "var(--text-main)" }}>
            Charting library not found
          </div>
          <div style={{ fontSize: 12, maxWidth: 420, lineHeight: 1.6 }}>
            Place the TradingView Advanced Charting Library files under{" "}
            <code style={{ color: "var(--accent-orange)" }}>public/charting_library/</code> (the file{" "}
            <code style={{ color: "var(--accent-orange)" }}>charting_library.js</code> must exist there),
            then reload this page.
          </div>
          {!activeSessionId && (
            <div style={{ fontSize: 11, opacity: 0.7 }}>
              Open the dashboard to create or load a session once the library is installed.
            </div>
          )}
        </div>
      )}
    </div>
  );
}