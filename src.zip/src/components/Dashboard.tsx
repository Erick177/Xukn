"use client";

import { memo, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";
import { exportSessionsToFile, importSessionsFromFile, mergeSessions } from "@/lib/sessionIO";
import { detectPriceDecimals } from "@/lib/symbolMeta";
import type { Session } from "@/lib/types";
import Icon from "@/components/Icon";

// Fallback end date used when the user leaves "End limit" empty.
const DEFAULT_END_DATE = "2030-01-01T00:00";

/** Formats an epoch-ms timestamp as a value usable by <input type="datetime-local">. */
function toDatetimeLocal(epochMs: number): string {
  const d = new Date(epochMs);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Groups a flat list of relative file paths (e.g. "btcusd/btcusd 1h.csv") by their top-level folder. */
function groupFilesByFolder(files: string[]): Record<string, string[]> {
  const groups: Record<string, string[]> = {};
  for (const f of files) {
    const segments = f.split("/");
    const folder = segments.length > 1 ? segments[0] : "(root)";
    if (!groups[folder]) groups[folder] = [];
    groups[folder].push(f);
  }
  return groups;
}

function computeStats(session: Session) {
  const trades = session.tradeJournal || [];
  const total = trades.length;
  const wins = trades.filter((t) => parseFloat(t.pnl) > 0).length;
  const winRate = total > 0 ? ((wins / total) * 100).toFixed(1) : "0.0";
  const growth = (((session.currentBalance - session.initialBalance) / session.initialBalance) * 100).toFixed(2);
  return { total, winRate, growth };
}

const SessionCard = memo(function SessionCard({
  session,
  isActive,
  onLoad,
  onDelete,
}: {
  session: Session;
  isActive: boolean;
  onLoad: (session: Session) => void;
  onDelete: (id: number) => void;
}) {
  const { total, winRate, growth } = useMemo(
    () => computeStats(session),
    [session.tradeJournal, session.currentBalance, session.initialBalance],
  );

  return (
    <div
      className={`sess-card ${isActive ? "sess-active" : ""}`}
      style={{ border: `1px solid ${isActive ? "var(--accent-blue)" : "var(--border-color)"}` }}
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        <span
          style={{
            fontWeight: 700,
            fontSize: 14,
            color: "#fff",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {session.symbol}
        </span>
        <span
          title={session.fileName}
          style={{
            fontSize: 10,
            color: "var(--text-muted)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {session.fileName}
        </span>
        <span style={{ fontSize: 9, color: "var(--text-muted)", fontFamily: "monospace" }}>
          Trades: {total}
        </span>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 6,
          background: "rgba(0,0,0,0.15)",
          padding: 8,
          borderRadius: 6,
          fontSize: 11,
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span style={{ color: "var(--text-muted)" }}>Balance:</span>
          <strong>${session.currentBalance.toFixed(2)}</strong>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span style={{ color: "var(--text-muted)" }}>WinRate:</span>
          <strong>{winRate}%</strong>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span style={{ color: "var(--text-muted)" }}>Growth:</span>
          <strong style={{ color: parseFloat(growth) >= 0 ? "var(--accent-green)" : "var(--accent-red)" }}>
            {growth}%
          </strong>
        </div>
      </div>

      <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
        <button
          className="btn btn-sess-load"
          style={{ flex: 1, height: 26, fontSize: 11, fontWeight: 600, color: "#fff", border: "none", borderRadius: 6, cursor: "pointer", background: "var(--accent-blue)" }}
          onClick={() => onLoad(session)}
        >
          {isActive ? "Resume" : "Load"}
        </button>
        <button
          className="btn"
          style={{ height: 26, fontSize: 11, color: "var(--accent-red)", background: "transparent", border: "1px solid rgba(239,83,80,0.2)" }}
          onClick={() => onDelete(session.id)}
        >
          Delete
        </button>
      </div>
    </div>
  );
});

export default function Dashboard() {
  const open = useReplayStore((s) => s.dashboardOpen);
  const closeDashboard = useReplayStore((s) => s.closeDashboard);
  const sessions = useReplayStore((s) => s.sessions);
  const setSessions = useReplayStore((s) => s.setSessions);
  const upsertSession = useReplayStore((s) => s.upsertSession);
  const removeSession = useReplayStore((s) => s.removeSession);
  const activeSessionId = useReplayStore((s) => s.activeSessionId);
  const setActiveSessionId = useReplayStore((s) => s.setActiveSessionId);
  const pushToast = useReplayStore((s) => s.pushToast);

  const [showForm, setShowForm] = useState(false);
  const [files, setFiles] = useState<string[]>([]);
  const [creating, setCreating] = useState(false);
  const importInputRef = useRef<HTMLInputElement>(null);

  const [symbol, setSymbol] = useState("");
  const [fileName, setFileName] = useState("");
  const [balance, setBalance] = useState("10000");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [minStartDate, setMinStartDate] = useState<string>("");
  const [rangeLoading, setRangeLoading] = useState(false);

  const decimals = fileName ? detectPriceDecimals(fileName) : null;
  const groupedFiles = useMemo(() => groupFilesByFolder(files), [files]);

  useEffect(() => {
    if (!open) return;
    fetch("/api/data")
      .then((r) => (r.ok ? r.json() : []))
      .then((list: string[]) => setFiles(list))
      .catch(() => setFiles([]));
  }, [open]);

  // When a data file is selected, look up its first/last bar dates so we can
  // pre-fill the session window and prevent picking a start before the data begins.
  useEffect(() => {
    if (!fileName) {
      setMinStartDate("");
      return;
    }
    let cancelled = false;
    setRangeLoading(true);
    fetch(`/api/data/range?file=${encodeURIComponent(fileName)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((range: { start: number; end: number } | null) => {
        if (cancelled || !range) return;
        setMinStartDate(toDatetimeLocal(range.start));
        setStartDate(toDatetimeLocal(range.start));
        setEndDate(toDatetimeLocal(range.end));
      })
      .catch(() => {
        if (!cancelled) setMinStartDate("");
      })
      .finally(() => {
        if (!cancelled) setRangeLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [fileName]);

  if (!open) return null;

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    if (!symbol || !fileName || !balance || !startDate) {
      pushToast("Please fill all fields.", "error");
      return;
    }
    if (minStartDate && startDate < minStartDate) {
      pushToast("Start point can't be before the data's first candle.", "error");
      return;
    }
    setCreating(true);
    try {
      const effectiveEndDate = endDate || DEFAULT_END_DATE;
      const session: Session = {
        id: Date.now(),
        symbol,
        fileName,
        initialBalance: parseFloat(balance),
        currentBalance: parseFloat(balance),
        priceDecimals: decimals ?? 5,
        startDate,
        endDate: effectiveEndDate,
        currentTimestamp: new Date(startDate).getTime(),
        timeframe: 1,
        replayIndex: 0,
        tradeJournal: [],
        positions: [],
        pendingOrders: [],
        createdAt: Date.now(),
      };
      upsertSession(session);
      setSymbol("");
      setFileName("");
      setStartDate("");
      setEndDate("");
      pushToast("Session created!", "success");
    } finally {
      setCreating(false);
    }
  }

  async function launchSession(session: Session) {
    setActiveSessionId(session.id);
    closeDashboard();
    await replayEngine.loadSession(session);
  }

  function deleteSession(id: number) {
    if (!window.confirm("Delete this session? All trades and progress will be removed.")) return;
    removeSession(id);
    pushToast("Session deleted", "info");
  }

  function handleExport() {
    exportSessionsToFile(sessions);
    pushToast("Sessions exported to a JSON file.", "success");
  }

  async function handleImportFile(file: File) {
    try {
      const incoming = await importSessionsFromFile(file);
      setSessions(mergeSessions(sessions, incoming));
      pushToast(`Imported ${incoming.length} session(s).`, "success");
    } catch (err) {
      pushToast(err instanceof Error ? err.message : "Import failed.", "error");
    }
  }

  return (
    <div className="modal-overlay active" id="dashboard-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <span style={{ fontSize: 16, fontWeight: 700, color: "#fff", display: "flex", alignItems: "center", gap: 12 }}>
            <Icon name="layout-dashboard" size={16} /> Backtest Dashboard
            <button
              className="btn"
              onClick={() => setShowForm((v) => !v)}
              style={{ height: 24, fontSize: 10, padding: "0 8px", borderRadius: 6, background: "rgba(255,255,255,0.05)" }}
            >
              <Icon name={showForm ? "eye-off" : "eye"} size={10} /> {showForm ? "Hide Creator" : "Show Creator"}
            </button>
          </span>

          <div style={{ display: "flex", gap: 6 }}>
            <button className="btn btn-blue" onClick={handleExport} title="Export all sessions to a JSON file">
              <Icon name="upload" size={12} /> Export
            </button>
            <button
              className="btn btn-orange"
              onClick={() => importInputRef.current?.click()}
              title="Import sessions from a JSON file"
            >
              <Icon name="download" size={12} /> Import
            </button>
            <input
              ref={importInputRef}
              type="file"
              accept="application/json"
              style={{ display: "none" }}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void handleImportFile(file);
                e.target.value = "";
              }}
            />
            <button
              className="btn btn-icon"
              onClick={() => {
                if (activeSessionId) closeDashboard();
                else pushToast("Create or load a session first.", "info");
              }}
            >
              <Icon name="x" size={14} />
            </button>
          </div>
        </div>

        <div className={`session-grid ${showForm ? "" : "hide-form"}`} id="main-dashboard-grid">
          <form className="form-section" id="create-session-form" onSubmit={handleCreate}>
            <div className="field-label">New Simulation</div>
            <input
              type="text"
              className="control-input"
              placeholder="Session / Symbol name"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              required
            />
            <select className="control-input" value={fileName} onChange={(e) => setFileName(e.target.value)} required>
              <option value="">{files.length ? "-- Select Data File --" : "Scanning /data …"}</option>
              {Object.entries(groupedFiles).map(([folder, folderFiles]) => (
                <optgroup key={folder} label={folder}>
                  {folderFiles.map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
            <input
              type="number"
              className="control-input"
              placeholder="Initial balance ($)"
              value={balance}
              onChange={(e) => setBalance(e.target.value)}
              required
            />
            <div className="field-label">
              Start point {rangeLoading ? "(loading data range…)" : ""}
            </div>
            <input
              type="datetime-local"
              className="control-input"
              value={startDate}
              min={minStartDate || undefined}
              onChange={(e) => setStartDate(e.target.value)}
              required
              disabled={!fileName}
            />
            <div className="field-label">End limit (optional — defaults to 2030)</div>
            <input
              type="datetime-local"
              className="control-input"
              value={endDate}
              min={minStartDate || undefined}
              onChange={(e) => setEndDate(e.target.value)}
              placeholder="Leave empty for 2030-01-01"
            />
            <button type="submit" className="btn btn-blue" style={{ height: 34, marginTop: "auto" }} disabled={creating}>
              <Icon name="plus-circle" size={14} />
              <span>{creating ? "Validating…" : "Create Session"}</span>
            </button>
          </form>

          <div style={{ display: "flex", flexDirection: "column", gap: 10, minHeight: 0 }}>
            <div className="field-label">Saved Sessions</div>
            <div className="list-section" id="dashboard-sessions-list">
              {sessions.length === 0 ? (
                <div style={{ color: "var(--text-muted)", textAlign: "center", gridColumn: "1/-1", padding: 40 }}>
                  No backtest sessions available.
                </div>
              ) : (
                sessions.map((session) => (
                  <SessionCard
                    key={session.id}
                    session={session}
                    isActive={session.id === activeSessionId}
                    onLoad={launchSession}
                    onDelete={deleteSession}
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}