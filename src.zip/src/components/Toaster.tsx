"use client";

import { useEffect } from "react";
import { useReplayStore } from "@/lib/store";

const KIND_COLORS: Record<string, string> = {
  success: "var(--accent-green)",
  error: "var(--accent-red)",
  warning: "var(--accent-orange)",
  info: "var(--accent-blue)",
};

export default function Toaster() {
  const toasts = useReplayStore((s) => s.toasts);
  const dismissToast = useReplayStore((s) => s.dismissToast);

  useEffect(() => {
    if (toasts.length === 0) return;
    const timers = toasts.map((t) => setTimeout(() => dismissToast(t.id), 2200));
    return () => timers.forEach(clearTimeout);
  }, [toasts, dismissToast]);

  if (toasts.length === 0) return null;

  return (
    <div
      style={{
        position: "fixed",
        bottom: 16,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 30000,
        display: "flex",
        flexDirection: "column",
        gap: 6,
        alignItems: "center",
      }}
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          style={{
            background: "var(--bg-panel)",
            border: `1px solid ${KIND_COLORS[t.kind] || "var(--border-color)"}`,
            color: "var(--text-main)",
            borderRadius: 8,
            padding: "8px 14px",
            fontSize: 12,
            boxShadow: "0 8px 24px rgba(0,0,0,.5)",
            minWidth: 180,
            textAlign: "center",
          }}
        >
          {t.text}
        </div>
      ))}
    </div>
  );
}
