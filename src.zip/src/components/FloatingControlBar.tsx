"use client";

import { useState, useEffect, useRef } from "react";
import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";
import Icon from "@/components/Icon";

const MIN_SPEED_MS = 30;
const MAX_SPEED_MS = 1000;

interface Position {
  x: number;
  y: number;
}

export default function FloatingControlBar() {
  const collapsed = useReplayStore((s) => s.controlBarCollapsed);
  const toggleControlBar = useReplayStore((s) => s.toggleControlBar);
  const playing = useReplayStore((s) => s.playing);
  const stepCount = useReplayStore((s) => s.stepCount);
  const setStepCount = useReplayStore((s) => s.setStepCount);
  const speedMs = useReplayStore((s) => s.speedMs);
  const setSpeedMs = useReplayStore((s) => s.setSpeedMs);

  const [localSpeed, setLocalSpeed] = useState(speedMs);
  const [position, setPosition] = useState<Position>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState<Position>({ x: 0, y: 0 });
  const barRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setLocalSpeed(speedMs);
  }, [speedMs]);

  useEffect(() => {
    const saved = localStorage.getItem("controlBarPosition");
    if (saved) {
      try {
        const pos = JSON.parse(saved);
        setPosition(pos);
      } catch {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("controlBarPosition", JSON.stringify(position));
  }, [position]);

  const sliderValue = Math.round(
    100 - ((localSpeed - MIN_SPEED_MS) / (MAX_SPEED_MS - MIN_SPEED_MS)) * 100
  );

  function handleSpeedChange(value: number) {
    const ms = MAX_SPEED_MS - (value / 100) * (MAX_SPEED_MS - MIN_SPEED_MS);
    const roundedMs = Math.round(ms);
    setLocalSpeed(roundedMs);
    setSpeedMs(roundedMs);
    replayEngine.setSpeed(roundedMs);
  }

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target instanceof HTMLButtonElement || e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) {
      return;
    }
    const rect = barRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
      setIsDragging(true);
    }
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const maxX = window.innerWidth - 400;
      const maxY = window.innerHeight - 80;
      setPosition({
        x: Math.max(0, Math.min(e.clientX - dragOffset.x, maxX)),
        y: Math.max(0, Math.min(e.clientY - dragOffset.y, maxY)),
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging, dragOffset]);

  if (collapsed) {
    return (
      <div
        style={{
          position: "fixed",
          top: position.y,
          left: position.x,
          background: "var(--bg-panel)",
          border: "1px solid var(--border-color)",
          borderRadius: 22,
          padding: "6px 12px",
          boxShadow: "none",
          zIndex: 10,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 6,
        }}
        onClick={toggleControlBar}
      >
        <span style={{ fontSize: 14, color: "var(--text-main)" }}>▶</span>
        <span style={{ fontSize: 12, color: "var(--accent-orange)", fontWeight: 600 }}>
          {Math.round(1000 / localSpeed)}x
        </span>
      </div>
    );
  }

  return (
    <div
      ref={barRef}
      style={{
        position: "fixed",
        top: position.y,
        left: position.x,
        background: "var(--bg-panel)",
        border: "1px solid var(--border-color)",
        borderRadius: 24,
        padding: "5px 14px",
        display: "flex",
        alignItems: "center",
        gap: 8,
        boxShadow: "none",
        zIndex: 10,
        cursor: isDragging ? "grabbing" : "grab",
        userSelect: "none",
      }}
      onMouseDown={handleMouseDown}
    >
      <button
        onClick={(e) => { e.stopPropagation(); replayEngine.togglePlay(); }}
        title="Play/Pause (Space)"
        style={{
          width: 32,
          height: 32,
          padding: 0,
          cursor: "pointer",
          background: "transparent",
          border: "none",
          color: "var(--text-main)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: "50%",
          transition: "background 0.15s",
        }}
        onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-btn)"}
        onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
      >
        <Icon name={playing ? "pause" : "play"} size={18} />
      </button>

      <button
        onClick={(e) => { e.stopPropagation(); replayEngine.stepForward(stepCount); }}
        title="Step Forward (→)"
        style={{
          width: 32,
          height: 32,
          padding: 0,
          cursor: "pointer",
          background: "transparent",
          border: "none",
          color: "var(--text-main)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: "50%",
          transition: "background 0.15s",
        }}
        onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-btn)"}
        onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
      >
        <Icon name="skip-forward" size={18} />
      </button>

      <select
        value={stepCount}
        onChange={(e) => setStepCount(parseInt(e.target.value, 10))}
        style={{
          background: "var(--bg-input)",
          border: "1px solid var(--border-color)",
          color: "var(--text-main)",
          borderRadius: 4,
          padding: "2px 4px",
          fontSize: 12,
          cursor: "pointer",
          outline: "none",
          width: 44,
          textAlign: "center",
          fontFamily: "monospace",
        }}
      >
        <option value={1}>1</option>
        <option value={5}>5</option>
        <option value={15}>15</option>
        <option value={60}>60</option>
        <option value={240}>240</option>
      </select>

      <input
        type="range"
        min={0}
        max={100}
        value={sliderValue}
        onChange={(e) => handleSpeedChange(parseInt(e.target.value, 10))}
        style={{
          width: 70,
          accentColor: "var(--accent-blue)",
          cursor: "pointer",
          height: 3,
          background: "transparent",
        }}
      />

      <span
        style={{
          fontSize: 12,
          color: "var(--accent-orange)",
          minWidth: 34,
          fontFamily: "monospace",
          fontWeight: 600,
        }}
      >
        {Math.round(1000 / localSpeed)}x
      </span>

      <button
        onClick={(e) => { e.stopPropagation(); toggleControlBar(); }}
        title="Collapse"
        style={{
          width: 26,
          height: 26,
          padding: 0,
          cursor: "pointer",
          fontSize: 14,
          lineHeight: 1,
          background: "transparent",
          border: "none",
          color: "var(--text-muted)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: "50%",
          transition: "background 0.15s, color 0.15s",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = "var(--bg-btn)";
          e.currentTarget.style.color = "var(--text-main)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "var(--text-muted)";
        }}
      >
        ◀
      </button>
    </div>
  );
}