"use client";

import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";
import Icon from "@/components/Icon";
import TradePanel from "@/components/TradePanel";
import PositionsPanel from "@/components/PositionsPanel";

export default function Sidebar() {
  const balance = useReplayStore((s) => s.balance);
  const candleLabel = useReplayStore((s) => s.candleLabel);
  const activeSessionId = useReplayStore((s) => s.activeSessionId);
  const sessions = useReplayStore((s) => s.sessions);
  const toggleTradePanel = useReplayStore((s) => s.toggleTradePanel);
  const toggleThemeManager = useReplayStore((s) => s.toggleThemeManager);
  const openDashboard = useReplayStore((s) => s.openDashboard);
  const pushToast = useReplayStore((s) => s.pushToast);

  function exportCsv() {
    const session = sessions.find((s) => s.id === activeSessionId);
    if (!session || session.tradeJournal.length === 0) {
      pushToast("No trades recorded.", "warning");
      return;
    }
    const rows = [
      ["Id", "Type", "Size", "EntryPrice", "ExitPrice", "Outcome", "PnL", "BalanceAfter", "Note", "Date"].join(","),
    ];
    for (const t of session.tradeJournal) {
      rows.push(
        [t.id, t.type, t.size, t.entryPrice, t.exitPrice, t.outcome, t.pnl, t.balanceAfter, t.note, t.date].join(","),
      );
    }
    const blob = new Blob(["\ufeff" + rows.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Session_Journal_${session.symbol}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div id="sidebar-panel">
      <div className="sidebar-top-row">
        <div className="panel-row" style={{ padding: "0 2px" }}>
          <span style={{ color: "var(--text-muted)" }}>|:</span>
          <span id="candle-counter" style={{ fontFamily: "monospace", color: "var(--accent-orange)" }}>
            {candleLabel}
          </span>
        </div>

        <div id="balance-row" className="panel-row">
          <span style={{ color: "var(--text-muted)", fontSize: 10, textTransform: "uppercase", letterSpacing: ".05em" }}>
            |
          </span>
          <span id="current-balance">${balance.toFixed(2)}</span>
        </div>

        <div className="btn-icon-row">
          <button className="btn" onClick={toggleTradePanel} title="Trade Panel [O]">
            <Icon name="layers" size={14} />
          </button>
          <button className="btn" onClick={exportCsv} title="Export Trade Journal CSV">
            <Icon name="download" size={14} />
          </button>
          <button className="btn" title="Chart Theme Manager [T]" onClick={() => toggleThemeManager()}>
            <Icon name="palette" size={14} />
          </button>
          <button className="btn btn-red" onClick={openDashboard} title="Dashboard [D]">
            <Icon name="settings" size={14} />
          </button>
        </div>
      </div>

      <TradePanel />
      <PositionsPanel />
    </div>
  );
}