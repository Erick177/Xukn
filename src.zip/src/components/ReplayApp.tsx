"use client";

import { useEffect, useCallback, useRef } from "react";
import { useReplayStore } from "@/lib/store";
import { replayEngine } from "@/lib/engine/replayEngine";
import { loadThemesFromBrowser, saveThemesToBrowser } from "@/lib/themeIO";
import { loadSessionsFromServer, saveSessionsToServer, deleteSessionFromServer } from "@/lib/sessionActions";

import ChartContainer from "@/components/ChartContainer";
import Sidebar from "@/components/Sidebar";
import FloatingControlBar from "@/components/FloatingControlBar";
import KeyboardHints from "@/components/KeyboardHints";
import Dashboard from "@/components/Dashboard";
import PositionDetailPanel from "@/components/PositionDetailPanel";
import ThemeManagerPanel from "@/components/ThemeManagerPanel";
import Toaster from "@/components/Toaster";

export default function ReplayApp() {
  const sessions = useReplayStore((s) => s.sessions);
  const setSessions = useReplayStore((s) => s.setSessions);
  const themes = useReplayStore((s) => s.themes);
  const setThemes = useReplayStore((s) => s.setThemes);
  const chartMode = useReplayStore((s) => s.chartMode);
  const setChartMode = useReplayStore((s) => s.setChartMode);
  const activeSessionId = useReplayStore((s) => s.activeSessionId);
  const dashboardOpen = useReplayStore((s) => s.dashboardOpen);
  const themeManagerOpen = useReplayStore((s) => s.themeManagerOpen);
  const toggleThemeManager = useReplayStore((s) => s.toggleThemeManager);
  const toggleTradePanel = useReplayStore((s) => s.toggleTradePanel);
  const setPositionDetailId = useReplayStore((s) => s.setPositionDetailId);
  const openDashboard = useReplayStore((s) => s.openDashboard);
  const closeDashboard = useReplayStore((s) => s.closeDashboard);
  const stepCount = useReplayStore((s) => s.stepCount);
  const pushToast = useReplayStore((s) => s.pushToast);

  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isInitialLoadRef = useRef(true);

  const saveSessions = useCallback(async (sessionsToSave: typeof sessions) => {
    if (sessionsToSave.length === 0) return;
    
    try {
      await saveSessionsToServer(sessionsToSave);
    } catch (error) {
      console.error("Failed to save sessions:", error);
      pushToast("Failed to save sessions to server", "error");
    }
  }, [pushToast]);

  const debouncedSave = useCallback((sessionsToSave: typeof sessions) => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    saveTimeoutRef.current = setTimeout(() => {
      saveSessions(sessionsToSave);
      saveTimeoutRef.current = null;
    }, 2000);
  }, [saveSessions]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [loadedSessions, loadedThemes] = await Promise.all([
          loadSessionsFromServer(),
          loadThemesFromBrowser()
        ]);
        
        setSessions(loadedSessions);
        setThemes(loadedThemes);
        
        if (loadedSessions.length > 0) {
          pushToast(`Loaded ${loadedSessions.length} sessions`, "info");
        }
      } catch (error) {
        console.error("Failed to load data:", error);
        pushToast("Failed to load sessions from server", "error");
      }
    };

    loadData();
  }, [setSessions, setThemes, pushToast]);

  useEffect(() => {
    if (isInitialLoadRef.current) {
      isInitialLoadRef.current = false;
      return;
    }

    if (sessions.length > 0) {
      debouncedSave(sessions);
    }
  }, [sessions, debouncedSave]);

  useEffect(() => {
    saveThemesToBrowser(themes);
  }, [themes]);

  useEffect(() => {
    const handleBeforeUnload = () => {
      if (sessions.length > 0) {
        saveSessions(sessions);
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
        if (sessions.length > 0) {
          saveSessions(sessions);
        }
      }
    };
  }, [sessions, saveSessions]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;

      switch (e.key) {
        case " ":
          e.preventDefault();
          replayEngine.togglePlay();
          break;
        case "ArrowRight":
        case "f":
        case "F":
          e.preventDefault();
          replayEngine.stepForward(stepCount);
          break;
        case "b":
        case "B":
          if (!activeSessionId) break;
          e.preventDefault();
          replayEngine.createOrder({
            type: "BUY",
            kind: useReplayStore.getState().orderKind,
            entryPrice: parseFloat(useReplayStore.getState().orderEntryPrice) || undefined,
            sl: parseFloat(useReplayStore.getState().orderSl),
            rr: parseFloat(useReplayStore.getState().orderRr) || 2,
            riskUsd: parseFloat(useReplayStore.getState().orderRiskUsd) || 10,
            note: useReplayStore.getState().orderNote,
          });
          break;
        case "s":
        case "S":
          if (!activeSessionId) break;
          e.preventDefault();
          replayEngine.createOrder({
            type: "SELL",
            kind: useReplayStore.getState().orderKind,
            entryPrice: parseFloat(useReplayStore.getState().orderEntryPrice) || undefined,
            sl: parseFloat(useReplayStore.getState().orderSl),
            rr: parseFloat(useReplayStore.getState().orderRr) || 2,
            riskUsd: parseFloat(useReplayStore.getState().orderRiskUsd) || 10,
            note: useReplayStore.getState().orderNote,
          });
          break;
        case "o":
        case "O":
          e.preventDefault();
          toggleTradePanel();
          break;
        case "d":
        case "D":
          e.preventDefault();
          openDashboard();
          break;
        case "t":
        case "T": {
          e.preventDefault();
          const next = chartMode === "dark" ? "light" : "dark";
          setChartMode(next);
          document.body.classList.toggle("light-theme", next === "light");
          replayEngine.applyChartMode(next);
          break;
        }
        case "Escape":
          toggleThemeManager(false);
          setPositionDetailId(null);
          if (activeSessionId) closeDashboard();
          break;
        default:
          break;
      }
    }

    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [
    activeSessionId,
    chartMode,
    stepCount,
    setChartMode,
    toggleThemeManager,
    toggleTradePanel,
    setPositionDetailId,
    openDashboard,
    closeDashboard,
  ]);

  return (
    <>
      <ChartContainer />
      <Sidebar />
      <FloatingControlBar />
      <KeyboardHints />
      {dashboardOpen && <Dashboard />}
      <PositionDetailPanel />
      {themeManagerOpen && <ThemeManagerPanel />}
      <Toaster />
    </>
  );
}