import { loadSeries } from "@/lib/loadSeries";
import type { CandleSeries } from "@/lib/candleSeries";

export interface DatasetResolution {
  url: string;
  format?: "csv" | "xbin";
}

export interface DatasetConfig {
  symbol: string;
  description?: string;
  exchange?: string;
  type?: string;
  pricescale?: number;
  resolutions: Record<string, DatasetResolution>;
}

type ResolutionString = string;

interface PeriodParams {
  from: number;
  to: number;
  firstDataRequest: boolean;
  countBack?: number;
}

interface LibrarySymbolInfo {
  name: string;
  full_name?: string;
  description?: string;
  ticker?: string;
  exchange?: string;
  type?: string;
  session?: string;
  timezone?: string;
  minmov?: number;
  pricescale?: number;
  has_intraday?: boolean;
  supported_resolutions?: ResolutionString[];
  volume_precision?: number;
  data_status?: string;
}

interface Bar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

interface DatafeedConfiguration {
  supported_resolutions: ResolutionString[];
  exchanges?: { value: string; name: string; desc: string }[];
  symbols_types?: { name: string; value: string }[];
}

export class StaticSeriesDatafeed {
  private datasets = new Map<string, DatasetConfig>();
  private cache = new Map<string, Promise<CandleSeries>>();

  constructor(datasets: DatasetConfig[], private opts: { useWorker?: boolean } = {}) {
    for (const d of datasets) {
      this.datasets.set(d.symbol.toUpperCase(), d);
    }
  }

  private cacheKey(symbol: string, resolution: string): string {
    return `${symbol.toUpperCase()}::${resolution}`;
  }

  private async getSeries(symbol: string, resolution: string): Promise<CandleSeries> {
    const key = this.cacheKey(symbol, resolution);
    let promise = this.cache.get(key);
    if (!promise) {
      const dataset = this.datasets.get(symbol.toUpperCase());
      if (!dataset) throw new Error(`Unknown symbol: ${symbol}`);
      const res = dataset.resolutions[resolution];
      if (!res) throw new Error(`No data configured for ${symbol} @ ${resolution}`);
      promise = loadSeries(res.url, {
        format: res.format,
        symbol,
        resolution,
        useWorker: this.opts.useWorker,
      });
      this.cache.set(key, promise);
    }
    return promise;
  }

  preload(symbol: string, resolution: string): Promise<CandleSeries> {
    return this.getSeries(symbol, resolution);
  }

  onReady(callback: (config: DatafeedConfiguration) => void): void {
    const resolutions = new Set<string>();
    for (const d of this.datasets.values()) {
      Object.keys(d.resolutions).forEach((r) => resolutions.add(r));
    }
    setTimeout(() => {
      callback({
        supported_resolutions: Array.from(resolutions) as ResolutionString[],
        exchanges: [{ value: "", name: "All", desc: "" }],
        symbols_types: [{ name: "crypto", value: "crypto" }],
      });
    }, 0);
  }

  searchSymbols(
    userInput: string,
    _exchange: string,
    _symbolType: string,
    onResult: (items: { symbol: string; full_name: string; description: string; exchange: string; ticker: string; type: string }[]) => void
  ): void {
    const q = userInput.toUpperCase();
    const results = Array.from(this.datasets.values())
      .filter((d) => d.symbol.toUpperCase().includes(q))
      .map((d) => ({
        symbol: d.symbol,
        full_name: d.symbol,
        description: d.description ?? d.symbol,
        exchange: d.exchange ?? "",
        ticker: d.symbol,
        type: d.type ?? "crypto",
      }));
    onResult(results);
  }

  resolveSymbol(
    symbolName: string,
    onResolve: (info: LibrarySymbolInfo) => void,
    onError: (reason: string) => void
  ): void {
    const dataset = this.datasets.get(symbolName.toUpperCase());
    if (!dataset) {
      onError("cannot resolve symbol");
      return;
    }
    setTimeout(() => {
      try {
        onResolve({
          name: dataset.symbol,
          full_name: dataset.symbol,
          description: dataset.description ?? dataset.symbol,
          ticker: dataset.symbol,
          exchange: dataset.exchange ?? "",
          type: dataset.type ?? "crypto",
          session: "24x7",
          timezone: "Etc/UTC",
          minmov: 1,
          pricescale: dataset.pricescale ?? 100000,
          has_intraday: true,
          supported_resolutions: Object.keys(dataset.resolutions) as ResolutionString[],
          volume_precision: 2,
          data_status: "streaming",
        });
      } catch (err) {
        onError(String(err));
      }
    }, 0);
  }

  async getBars(
    symbolInfo: LibrarySymbolInfo,
    resolution: ResolutionString,
    periodParams: PeriodParams,
    onResult: (bars: Bar[], meta: { noData: boolean }) => void,
    onError: (reason: string) => void
  ): Promise<void> {
    try {
      const series = await this.getSeries(symbolInfo.name, resolution);
      
      const from = periodParams.from || 0;
      const to = periodParams.to || Date.now() / 1000;
      const countBack = Math.min(periodParams.countBack || 500, 5000);
      
      if (series.length === 0) {
        onResult([], { noData: true });
        return;
      }
      
      const bars = series.toBars(from, to, countBack);
      
      if (bars.length === 0) {
        const lastBar = series.get(series.length - 1);
        onResult([{
          time: Math.floor(lastBar.time * 1000),
          open: Number(lastBar.open.toFixed(8)),
          high: Number(lastBar.high.toFixed(8)),
          low: Number(lastBar.low.toFixed(8)),
          close: Number(lastBar.close.toFixed(8)),
          volume: Number((lastBar.volume || 0).toFixed(2))
        }], { noData: false });
        return;
      }
      
      const formattedBars = bars.map((b) => ({
        time: Math.floor(b.time * 1000),
        open: Number(b.open.toFixed(8)),
        high: Number(b.high.toFixed(8)),
        low: Number(b.low.toFixed(8)),
        close: Number(b.close.toFixed(8)),
        volume: Number((b.volume || 0).toFixed(2))
      }));
      
      onResult(formattedBars, { noData: false });
    } catch (err) {
      console.error('Error in getBars:', err);
      onError(err instanceof Error ? err.message : String(err));
    }
  }

  subscribeBars(): void {
  }

  unsubscribeBars(): void {
  }
}