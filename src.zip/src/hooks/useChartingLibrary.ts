"use client";

import { useEffect } from "react";
import { useReplayStore } from "@/lib/store";

/**
 * Loads the TradingView Advanced Charting Library from the public folder.
 * The library itself is NOT bundled with this project (see README) — the
 * integrator must place it under `public/charting_library/`. If it can't be
 * found we simply flag `libraryMissing` so the UI can show guidance instead
 * of crashing.
 */
export function useChartingLibrary() {
  const setLibraryMissing = useReplayStore((s) => s.setLibraryMissing);

  useEffect(() => {
    if (window.TradingView) {
      setLibraryMissing(false);
      return;
    }

    const existing = document.getElementById("tv-charting-library-script");
    if (existing) return;

    const script = document.createElement("script");
    script.id = "tv-charting-library-script";
    script.src = "/charting_library/charting_library.js";
    script.async = true;
    script.onload = () => setLibraryMissing(!window.TradingView);
    script.onerror = () => setLibraryMissing(true);
    document.body.appendChild(script);

    const timeout = setTimeout(() => {
      if (!window.TradingView) setLibraryMissing(true);
    }, 4000);

    return () => clearTimeout(timeout);
  }, [setLibraryMissing]);
}
