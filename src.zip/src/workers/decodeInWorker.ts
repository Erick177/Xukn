/**
 * Thin promise-based wrapper around xbinDecode.worker.ts. Falls back to
 * decoding on the main thread transparently if Workers are unavailable
 * (e.g. some SSR/test environments).
 */
import { DecodedSeries } from "../lib/xbin/constants";
import { decodeXbin } from "../lib/xbin/decode";
import type { WorkerRequest, WorkerResponseErr, WorkerResponseOk } from "./xbinDecode.worker";

let worker: Worker | null = null;
let nextId = 1;
const pending = new Map<number, { resolve: (v: DecodedSeries) => void; reject: (e: Error) => void }>();

function getWorker(): Worker | null {
  if (typeof Worker === "undefined") return null;
  if (!worker) {
    worker = new Worker(new URL("./xbinDecode.worker.ts", import.meta.url), { type: "module" });
    worker.onmessage = (ev: MessageEvent<WorkerResponseOk | WorkerResponseErr>) => {
      const msg = ev.data;
      const entry = pending.get(msg.id);
      if (!entry) return;
      pending.delete(msg.id);
      if (msg.ok) {
        entry.resolve({
          symbol: msg.symbol,
          resolution: msg.resolution,
          priceScale: msg.priceScale,
          count: msg.times.byteLength / 8,
          times: new Float64Array(msg.times),
          open: new Float32Array(msg.open),
          high: new Float32Array(msg.high),
          low: new Float32Array(msg.low),
          close: new Float32Array(msg.close),
          volume: msg.volume ? new Float32Array(msg.volume) : null,
        });
      } else {
        entry.reject(new Error(msg.error));
      }
    };
  }
  return worker;
}

export async function decodeXbinInWorker(buffer: ArrayBuffer): Promise<DecodedSeries> {
  const w = getWorker();
  if (!w) return decodeXbin(buffer); // graceful fallback

  const id = nextId++;
  // Transfer a copy of the buffer's bytes so the caller keeps ownership of `buffer`.
  const copy = buffer.slice(0);
  return new Promise<DecodedSeries>((resolve, reject) => {
    pending.set(id, { resolve, reject });
    const req: WorkerRequest = { id, buffer: copy };
    w.postMessage(req, [copy]);
  });
}
