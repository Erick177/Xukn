/**
 * Dedicated Web Worker that gunzips + decodes .xbin files off the main
 * thread. Results are transferred back with a transfer list (zero-copy) so
 * the potentially large typed arrays are moved, not cloned — keeping peak
 * memory usage low even for very large datasets.
 */
import { decodeXbinSync } from "../lib/xbin/decode";

export interface WorkerRequest {
  id: number;
  buffer: ArrayBuffer;
}

export interface WorkerResponseOk {
  id: number;
  ok: true;
  symbol: string;
  resolution: string;
  priceScale: number;
  times: ArrayBuffer;
  open: ArrayBuffer;
  high: ArrayBuffer;
  low: ArrayBuffer;
  close: ArrayBuffer;
  volume: ArrayBuffer | null;
}

export interface WorkerResponseErr {
  id: number;
  ok: false;
  error: string;
}

self.onmessage = (ev: MessageEvent<WorkerRequest>) => {
  const { id, buffer } = ev.data;
  try {
    const decoded = decodeXbinSync(new Uint8Array(buffer));
    const response: WorkerResponseOk = {
      id,
      ok: true,
      symbol: decoded.symbol,
      resolution: decoded.resolution,
      priceScale: decoded.priceScale,
      times: decoded.times.buffer as ArrayBuffer,
      open: decoded.open.buffer as ArrayBuffer,
      high: decoded.high.buffer as ArrayBuffer,
      low: decoded.low.buffer as ArrayBuffer,
      close: decoded.close.buffer as ArrayBuffer,
      volume: decoded.volume ? (decoded.volume.buffer as ArrayBuffer) : null,
    };
    const transfer: ArrayBuffer[] = [response.times, response.open, response.high, response.low, response.close];
    if (response.volume) transfer.push(response.volume);
    (self as unknown as Worker).postMessage(response, transfer);
  } catch (err) {
    const response: WorkerResponseErr = { id, ok: false, error: err instanceof Error ? err.message : String(err) };
    (self as unknown as Worker).postMessage(response);
  }
};
