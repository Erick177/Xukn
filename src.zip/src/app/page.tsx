import ReplayApp from "@/components/ReplayApp";

export default function HomePage() {
  return <ReplayApp />;
}
