import path from "path";
import fs from "fs";
import { gunzipSync } from "zlib";
import { readHeader } from "@/lib/xbin/constants";

export const dynamic = "force-dynamic";

const DATA_DIR = path.join(process.cwd(), "data");

function resolveSafePath(file: string): string | null {
  const directPath = path.join(DATA_DIR, file);
  if (fs.existsSync(directPath)) {
    return directPath;
  }
  
  const normalized = path.normalize(file).replace(/^(\.\.(\/|\\|$))+/, "");
  const resolved = path.resolve(DATA_DIR, normalized);
  const relativeToBase = path.relative(DATA_DIR, resolved);
  if (relativeToBase.startsWith("..") || path.isAbsolute(relativeToBase)) return null;
  return resolved;
}

function readXbinBars(filePath: string, from: number, countBack: number): any[] {
  try {
    const fileBuffer = fs.readFileSync(filePath);
    
    const isGzipped = fileBuffer.length >= 2 && fileBuffer[0] === 0x1F && fileBuffer[1] === 0x8B;
    
    let buffer = fileBuffer;
    if (isGzipped) {
      try {
        buffer = gunzipSync(fileBuffer);
      } catch {
        return [];
      }
    }
    
    const header = readHeader(buffer);
    
    if (!header || header.count === 0) return [];
    
    let offset = 4 + 1 + 1 + 2 + 4 + 4 + 8 + 4;
    
    const symbolLen = new DataView(buffer.buffer, buffer.byteOffset + offset, 2).getUint16(0, true);
    offset += 2 + symbolLen;
    
    const resolutionLen = new DataView(buffer.buffer, buffer.byteOffset + offset, 2).getUint16(0, true);
    offset += 2 + resolutionLen;
    
    offset = (offset + 3) & ~3;
    
    const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.length);
    
    let startIndex = 0;
    const priceScale = header.priceScale;
    const baseTime = header.baseTime;
    const timeStep = header.timeStep;
    const count = header.count;
    const hasVolume = (header.flags & 1) === 1;
    
    if (from > 0) {
      let low = 0;
      let high = count - 1;
      
      while (low <= high) {
        const mid = Math.floor((low + high) / 2);
        let time: number;
        
        if (timeStep > 0) {
          time = baseTime + mid * timeStep;
        } else {
          const deltaOffset = offset + (mid - 1) * 4;
          if (mid === 0) {
            time = baseTime;
          } else {
            const delta = view.getInt32(deltaOffset, true);
            time = baseTime + delta;
          }
        }
        
        if (time >= from) {
          high = mid - 1;
        } else {
          low = mid + 1;
        }
      }
      startIndex = low;
    }
    
    const maxBars = Math.min(countBack || 500, 5000);
    
    if (countBack > 0 && startIndex + maxBars > count) {
      startIndex = Math.max(0, count - maxBars);
    }
    
    const endIndex = Math.min(startIndex + maxBars, count);
    const barCount = endIndex - startIndex;
    
    if (barCount <= 0) return [];
    
    let dataOffset = offset;
    
    if (timeStep === 0) {
      dataOffset += (count - 1) * 4;
    }
    
    const openDeltaOffset = dataOffset;
    dataOffset += count * 4;
    
    const highRelOffset = dataOffset;
    dataOffset += count * 4;
    
    const lowRelOffset = dataOffset;
    dataOffset += count * 4;
    
    const closeRelOffset = dataOffset;
    dataOffset += count * 4;
    
    const volumeOffset = hasVolume ? dataOffset : -1;
    
    const bars: any[] = [];
    let prevOpen = 0;
    let prevTime = baseTime;
    
    for (let i = startIndex; i < endIndex; i++) {
      let time: number;
      if (timeStep > 0) {
        time = baseTime + i * timeStep;
      } else {
        if (i === 0) {
          time = baseTime;
        } else {
          const deltaOffset = offset + (i - 1) * 4;
          const delta = view.getInt32(deltaOffset, true);
          time = baseTime + delta;
        }
      }
      
      const openDelta = view.getInt32(openDeltaOffset + i * 4, true);
      const open = (i === 0 ? openDelta : prevOpen + openDelta) / priceScale;
      prevOpen = open * priceScale;
      
      const highRel = view.getInt32(highRelOffset + i * 4, true);
      const lowRel = view.getInt32(lowRelOffset + i * 4, true);
      const closeRel = view.getInt32(closeRelOffset + i * 4, true);
      
      const high = (prevOpen + highRel) / priceScale;
      const low = (prevOpen - lowRel) / priceScale;
      const close = (prevOpen + closeRel) / priceScale;
      
      let volume = 0;
      if (hasVolume && volumeOffset > 0) {
        volume = view.getFloat32(volumeOffset + i * 4, true);
      }
      
      bars.push({
        time: Math.floor(time * 1000),
        open: Number(open.toFixed(8)),
        high: Number(high.toFixed(8)),
        low: Number(low.toFixed(8)),
        close: Number(close.toFixed(8)),
        volume: Number(volume.toFixed(2)),
      });
    }
    
    return bars;
  } catch (error) {
    console.error("Error reading XBIN:", error);
    return [];
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const file = searchParams.get("file");
  const from = Number(searchParams.get("from") || 0);
  const countBack = Number(searchParams.get("countBack") || 500);

  if (!file) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  const filePath = resolveSafePath(file);
  if (!filePath) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  try {
    if (file.endsWith('.xbin')) {
      const bars = readXbinBars(filePath, from, Math.min(countBack, 5000));
      return Response.json(bars);
    }

    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content.split('\n').filter(l => l.trim());
      const bars: any[] = [];
      
      for (let i = 0; i < Math.min(lines.length, 5000); i++) {
        const parts = lines[i].split(',');
        if (parts.length >= 5) {
          const time = new Date(parts[0].trim()).getTime();
          if (!isNaN(time)) {
            bars.push({
              time: Math.floor(time),
              open: Number(parseFloat(parts[1]).toFixed(8)),
              high: Number(parseFloat(parts[2]).toFixed(8)),
              low: Number(parseFloat(parts[3]).toFixed(8)),
              close: Number(parseFloat(parts[4]).toFixed(8)),
              volume: parts[5] ? Number(parseFloat(parts[5]).toFixed(2)) : 0,
            });
          }
        }
      }
      
      return Response.json(bars);
    } catch {
      return Response.json([]);
    }
  } catch (error) {
    console.error("Error reading file:", error);
    return Response.json({ error: "File not found" }, { status: 404 });
  }
}