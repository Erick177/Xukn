import path from "path";
import { readBarsStream } from "@/lib/streamCsv";

export const dynamic = "force-dynamic";

const DATA_DIR = path.join(process.cwd(), "data");

/**
 * Resolves a user-supplied relative file path against DATA_DIR, rejecting
 * anything that would escape it (e.g. "../secrets"). Supports nested
 * folders like "btcusd/btcusd 1h.csv".
 */
function resolveSafePath(file: string): string | null {
  const normalized = path.normalize(file).replace(/^(\.\.(\/|\\|$))+/, "");
  const resolved = path.resolve(DATA_DIR, normalized);
  const relativeToBase = path.relative(DATA_DIR, resolved);
  if (relativeToBase.startsWith("..") || path.isAbsolute(relativeToBase)) return null;
  return resolved;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const file = searchParams.get("file");
  const from = Number(searchParams.get("from") || 0);
  const countBack = Number(searchParams.get("countBack") || 5000);

  if (!file) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  const filePath = resolveSafePath(file);
  if (!filePath) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  try {
    // Streams the file line-by-line instead of loading it fully into memory.
    const bars = await readBarsStream(filePath, { from, countBack });
    return Response.json(bars);
  } catch {
    return Response.json({ error: "File not found" }, { status: 404 });
  }
}
