import path from "path";
import { readFirstLastTimestamps } from "@/lib/streamCsv";

export const dynamic = "force-dynamic";

const DATA_DIR = path.join(process.cwd(), "data");

function resolveSafePath(file: string): string | null {
  const normalized = path.normalize(file).replace(/^(\.\.(\/|\\|$))+/, "");
  const resolved = path.resolve(DATA_DIR, normalized);
  const relativeToBase = path.relative(DATA_DIR, resolved);
  if (relativeToBase.startsWith("..") || path.isAbsolute(relativeToBase)) return null;
  return resolved;
}

/**
 * Returns the first and last bar timestamps (epoch ms) found in the given
 * data file, so the UI can pre-fill / constrain the session creator's
 * start & end date fields. Only reads a small chunk from the start and end
 * of the file — never the whole thing — so this stays cheap even for very
 * large files.
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const file = searchParams.get("file");

  if (!file) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  const filePath = resolveSafePath(file);
  if (!filePath) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  try {
    const range = await readFirstLastTimestamps(filePath);
    if (!range) {
      return Response.json({ error: "No data in file" }, { status: 404 });
    }
    return Response.json(range);
  } catch {
    return Response.json({ error: "File not found" }, { status: 404 });
  }
}
