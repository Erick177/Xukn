// src/app/api/data/range/route.ts

import path from "path";
import fs from "fs";
import { gunzipSync } from "zlib";
import { XBIN_MAGIC_BYTES, XBIN_VERSION } from "@/lib/xbin/constants";

export const dynamic = "force-dynamic";

const DATA_DIR = path.join(process.cwd(), "data");

function resolveSafePath(file: string): string | null {
  const directPath = path.join(DATA_DIR, file);
  if (fs.existsSync(directPath)) {
    return directPath;
  }
  
  const normalized = path.normalize(file).replace(/^(\.\.(\/|\\|$))+/, "");
  const resolved = path.resolve(DATA_DIR, normalized);
  const relativeToBase = path.relative(DATA_DIR, resolved);
  if (relativeToBase.startsWith("..") || path.isAbsolute(relativeToBase)) return null;
  return resolved;
}

function readXbinHeader(buffer: Buffer): {
  count: number;
  baseTime: number;
  timeStep: number;
  symbol: string;
  resolution: string;
} | null {
  try {
    if (buffer.length < 32) return null;
    
    const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.length);
    let offset = 0;
    
    for (let i = 0; i < 4; i++) {
      if (view.getUint8(offset + i) !== XBIN_MAGIC_BYTES[i]) {
        return null;
      }
    }
    offset += 4;
    
    const version = view.getUint8(offset);
    offset += 1;
    if (version !== XBIN_VERSION) return null;
    
    offset += 1 + 2;
    offset += 4;
    
    const count = view.getUint32(offset, true);
    offset += 4;
    
    const baseTime = view.getFloat64(offset, true);
    offset += 8;
    
    const timeStep = view.getInt32(offset, true);
    offset += 4;
    
    const symbolLen = view.getUint16(offset, true);
    offset += 2;
    const symbol = new TextDecoder().decode(buffer.slice(offset, offset + symbolLen));
    offset += symbolLen;
    
    const resolutionLen = view.getUint16(offset, true);
    offset += 2;
    const resolution = new TextDecoder().decode(buffer.slice(offset, offset + resolutionLen));
    
    return { count, baseTime, timeStep, symbol, resolution };
  } catch {
    return null;
  }
}

function getXbinRange(filePath: string): { start: number; end: number } | null {
  try {
    if (!fs.existsSync(filePath)) {
      return null;
    }
    
    const fileBuffer = fs.readFileSync(filePath);
    
    const isGzipped = fileBuffer.length >= 2 && fileBuffer[0] === 0x1F && fileBuffer[1] === 0x8B;
    
    let dataBuffer = fileBuffer;
    if (isGzipped) {
      try {
        dataBuffer = gunzipSync(fileBuffer);
      } catch {
        return null;
      }
    }
    
    const header = readXbinHeader(dataBuffer);
    if (!header || header.count === 0) return null;
    
    const start = Math.floor(header.baseTime);
    
    if (header.timeStep > 0) {
      return {
        start,
        end: Math.floor(header.baseTime + (header.count - 1) * header.timeStep),
      };
    }
    
    let offset = 4 + 1 + 1 + 2 + 4 + 4 + 8 + 4;
    offset += 2 + header.symbol.length;
    offset += 2 + header.resolution.length;
    offset = (offset + 3) & ~3;
    
    if (header.count > 1) {
      const lastDeltaOffset = offset + (header.count - 2) * 4;
      const view = new DataView(dataBuffer.buffer, dataBuffer.byteOffset, dataBuffer.length);
      if (lastDeltaOffset + 4 <= dataBuffer.length) {
        const lastDelta = view.getInt32(lastDeltaOffset, true);
        return {
          start,
          end: Math.floor(header.baseTime + lastDelta),
        };
      }
    }
    
    return { start, end: start };
  } catch (error) {
    console.error("Error reading XBIN range:", error);
    return null;
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const file = searchParams.get("file");

  if (!file) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  const filePath = resolveSafePath(file);
  if (!filePath) {
    return Response.json({ error: "Invalid file" }, { status: 400 });
  }

  try {
    if (file.endsWith('.xbin')) {
      const range = getXbinRange(filePath);
      if (!range) {
        return Response.json({ error: "No data in file" }, { status: 404 });
      }
      return Response.json(range);
    }

    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content.split('\n').filter(l => l.trim());
      
      if (lines.length === 0) {
        return Response.json({ error: "Empty file" }, { status: 404 });
      }
      
      let firstTime = null;
      let lastTime = null;
      
      const parseTime = (line: string) => {
        const parts = line.split(',');
        if (parts.length >= 1) {
          const t = new Date(parts[0].trim());
          return t.getTime() / 1000;
        }
        return NaN;
      };
      
      for (let i = 0; i < Math.min(lines.length, 20); i++) {
        const time = parseTime(lines[i]);
        if (!isNaN(time)) {
          firstTime = time;
          break;
        }
      }
      
      for (let i = Math.min(lines.length - 1, lines.length - 1); i >= Math.max(0, lines.length - 20); i--) {
        const time = parseTime(lines[i]);
        if (!isNaN(time)) {
          lastTime = time;
          break;
        }
      }
      
      if (firstTime !== null && lastTime !== null) {
        return Response.json({ start: firstTime, end: lastTime });
      }
    } catch {
      // ignore
    }

    return Response.json({ error: "No data in file" }, { status: 404 });
  } catch (error) {
    console.error("Error in range API:", error);
    return Response.json({ error: "File not found" }, { status: 404 });
  }
}