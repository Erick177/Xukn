// src/app/api/data/route.ts

import { promises as fs } from "fs";
import path from "path";

export const dynamic = "force-dynamic";

const DATA_DIR = path.join(process.cwd(), "data");
const ALLOWED_EXTENSIONS = [".csv", ".tsv", ".txt", ".xbin"];

async function scanDir(dir: string, baseDir: string): Promise<string[]> {
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return [];
  }

  const results: string[] = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const nested = await scanDir(fullPath, baseDir);
      results.push(...nested);
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      if (ALLOWED_EXTENSIONS.includes(ext)) {
        const relative = path.relative(baseDir, fullPath).split(path.sep).join("/");
        results.push(relative);
      }
    }
  }
  return results;
}

export async function GET() {
  try {
    const files = await scanDir(DATA_DIR, DATA_DIR);
    files.sort((a, b) => a.localeCompare(b));
    return Response.json(files);
  } catch {
    return Response.json([]);
  }
}